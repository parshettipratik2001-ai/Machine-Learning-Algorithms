# Stock Price Prediction — Model Comparison

Educational project for an academic presentation. It predicts the **next trading day's closing price** for Apple, Tesla, Microsoft, or the NIFTY 50, and compares three forecasts on a time-ordered test set.

This is not a trading system and it is not financial advice.

## What the project predicts

At the close of day *t* the model predicts the return on day *t+1*:

```text
target return = (tomorrow's close - today's close) / today's close
predicted close = today's close x (1 + predicted return)
```

Predicting the return, rather than the price itself, stops the result from looking better than it is. Tomorrow's price is almost the same as today's, so a forecast of "no change" already sits close to the real line. The project therefore always shows that no-change forecast next to the learned models.

## Why these two algorithms

**Linear Regression** is the model to explain first. It finds one weight per feature:

```text
predicted return = w1·return_1 + w2·ma_5_ratio + ... + b
```

The weights minimise the squared error on the training days. A positive weight means a higher feature value pushes the predicted return up. The relationship has to be a straight line, which is why it is the baseline.

**Random Forest** is the main model. Each decision tree asks a chain of yes/no questions ("is 10-day volatility high?", "is the open-close difference negative?") and ends at a predicted return. One tree memorises the past. The forest grows 300 trees, each on a random sample of rows and a random subset of features, then averages their answers. Tree depth is capped at 6 so a tree cannot grow until it has memorised every training day.

The random seed (default 42) only changes which rows and features each tree sees. It does not shuffle time.

## The six steps, in the order to present them

1. **Data collection and exploration.** Daily bars from Yahoo Finance are saved in `data/`, so the demo runs offline. Adjusted closes are used for the US stocks, which removes the fake crash caused by a stock split.
2. **Preprocessing and feature engineering.** Dates are sorted, duplicates dropped, and missing prices removed. Features use only information known at today's close: recent returns, distance from the 5-, 10-, and 20-day moving averages, 10-day volatility, the open-close difference, the high-low range, and the change in volume.
3. **Train-test split.** The last 20% of rows (the slider in the app) is the test set. The earlier rows are the training set. Nothing is shuffled, so the model is never tested on a day it has already seen.
4. **Model building.** A no-change baseline, linear regression, and a random forest are fit on the training rows only. The linear model scales features inside a pipeline, so the scaler is not fit on the test set.
5. **Evaluation.** RMSE and MAE compare predicted and actual next closes. Return RMSE and R² score the percentage change. Direction accuracy is the share of test days where the model got UP versus DOWN right. About 50% is a coin flip.
6. **Visualisation.** The app and the notebook plot actual against predicted closes, a scatter around the perfect-prediction line, a direction confusion matrix, and random-forest feature importance.

## What to say about the scores

Run the default Apple example (test size 0.20, seed 42) and read the numbers from the table. On this data the learned models do **not** beat "tomorrow's close equals today's close" on price RMSE, and direction accuracy sits near 50–52%.

Say that directly. The chart looks accurate because the two price lines stay near each other. The RMSE against the naive forecast is the number that matters. NIFTY 50 is slightly kinder to the forest on the same settings; still describe it as a small edge, not a trading signal.

A useful closing line: *"The pipeline is built without leakage. The result is that next-day direction is close to a coin flip, which is what a liquid market should look like."*

## Two further trainings

The same features and the same chronological split support two classification questions. Both are scored against a majority-class baseline: always guess the label that was more common on the training days. A learned model is described as beating that baseline only when it leads by more than one percentage point.

**Bullish or bearish.** The label is the sign of the return over the next 10 sessions. Bullish means the close 10 sessions ahead is higher than today's close. Bearish means it is not. The last 10 sessions have no answer yet, so they are left out of the accuracy. The page also shows the random forest's call on the latest close, marked unscored when those 10 sessions are unfinished.

**Entry, exit, or quiet.** Public prices do not name who bought or sold. A finished session is Entry when the close rose and volume was at least its own 20-day average, Exit when the close fell on that same volume test, and Quiet when volume was below the average. The model predicts the next session's label. Yahoo's volume figure compares how busy one day was with another. It is not a headcount of investors.

The Union Budget block is a case study, not a third model. `data/union_budgets.csv` lists the speech dates from 2015 through 2026. Each date is mapped to the NIFTY session on that day, or to the next open session within three calendar days. The table shows that session's return, its volume versus the recent average, and the entry/exit/quiet label. The chart is the average NIFTY path from five sessions before the speech session to five sessions after. It always reads `data/NIFTY50.csv`, including when the sidebar dataset is Apple or Tesla.

## Project layout

| File | Role |
| --- | --- |
| `app.py` | Streamlit page used in the demo |
| `src/pipeline.py` | Loading, features, time split, the price model, and the two classifiers |
| `notebooks/stock_price_prediction.ipynb` | Same steps, with the plots, for the viva |
| `train.py` | Prints the price scores, both classifiers, and the NIFTY budget table |
| `download_data.py` | Optional refresh of the Yahoo Finance files |
| `data/` | Apple, Tesla, Microsoft, and NIFTY 50 daily history, plus `union_budgets.csv` |
| `requirements.txt` | Python packages |
| `Steps to run.md` | Setup commands |

## Run the demo

```bash
python -m venv venv
source venv/bin/activate          # Windows: venv\Scripts\activate
python -m pip install --upgrade pip
pip install -r requirements.txt
python -m streamlit run app.py
```

Full click-by-click steps are in `Steps to run.md`.
