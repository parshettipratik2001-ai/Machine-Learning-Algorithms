"""Streamlit front end for the stock-prediction project.

Run from the project folder:

    python -m streamlit run app.py
"""

from __future__ import annotations

from io import BytesIO
from pathlib import Path

import numpy as np
import pandas as pd
import plotly.graph_objects as go
import streamlit as st

from src.pipeline import (
    BUNDLED_DATASETS,
    FEATURE_COLUMNS,
    FEATURE_MEANINGS,
    STARTING_CAPITAL,
    best_against_majority,
    budget_event_study,
    classification_table,
    explore_prices,
    load_budget_calendar,
    load_prices,
    market_mood,
    paper_trading,
    results_table,
    run_pipeline,
    train_participation,
    train_regime,
)

DATA_DIR = Path(__file__).resolve().parent / "data"
BUDGET_CALENDAR = DATA_DIR / "union_budgets.csv"
PLOT_HEIGHT = 460
ACTUAL_COLOR = "#1f4e79"
PREDICTED_COLOR = "#d97706"
TEST_COLOR = "rgba(217, 119, 6, 0.12)"


st.set_page_config(
    page_title="Stock Price Prediction",
    page_icon="📈",
    layout="wide",
)


def pack_classification(outcome: dict) -> dict:
    """Keep scores and labels. Leave the fitted classifiers out of the cache."""
    packed = {
        "metrics": classification_table(outcome["results"]),
        "confusion": {
            item.name: item.confusion.tolist() for item in outcome["results"]
        },
        "labels": outcome["labels"],
        "train_start": outcome["train"]["Date"].iloc[0],
        "train_end": outcome["train"]["Date"].iloc[-1],
        "test_start": outcome["test"]["Date"].iloc[0],
        "test_end": outcome["test"]["Date"].iloc[-1],
        "train_rows": int(len(outcome["train"])),
        "test_rows": int(len(outcome["test"])),
        "summary": best_against_majority(outcome["results"]),
    }
    if "latest" in outcome:
        packed["horizon"] = int(outcome["horizon"])
        packed["latest"] = outcome["latest"]
    return packed


def read_bundled(dataset_key: str) -> bytes:
    path = DATA_DIR / f"{dataset_key}.csv"
    if not path.exists():
        raise FileNotFoundError(
            f"Bundled file data/{dataset_key}.csv is missing. "
            "Run python download_data.py or upload a CSV."
        )
    return path.read_bytes()


@st.cache_data(show_spinner=False)
def prepare_project_full(csv_bytes: bytes, test_size: float, seed: int) -> dict:
    """Train the comparison and return tables the page can draw.

    Fitted estimators are not cached. Scores, forecasts, and tables are enough
    for every chart on the page.
    """
    prices = load_prices(BytesIO(csv_bytes))
    outcome = run_pipeline(prices, test_size=test_size, seed=seed)
    regime = train_regime(prices, test_size=test_size, seed=seed)
    participation = train_participation(prices, test_size=test_size, seed=seed)
    packed_predictions = {
        item.name: item.predictions for item in outcome["results"]
    }
    packed_confusion = {
        item.name: item.confusion.tolist() for item in outcome["results"]
    }
    return {
        "prices": outcome["prices"],
        "featured": outcome["featured"],
        "train": outcome["train"],
        "test": outcome["test"],
        "metrics": results_table(outcome["results"]),
        "predictions": packed_predictions,
        "confusion": packed_confusion,
        "coefficients": outcome["coefficients"],
        "importances": outcome["importances"],
        "summary": explore_prices(prices),
        "regime": pack_classification(regime),
        "participation": pack_classification(participation),
    }


@st.cache_data(show_spinner=False)
def prepare_budget_study(nifty_bytes: bytes, calendar_bytes: bytes) -> dict:
    """Map Union Budget speeches onto NIFTY sessions. No model is fit here."""
    return budget_event_study(
        load_prices(BytesIO(nifty_bytes)),
        load_budget_calendar(BytesIO(calendar_bytes)),
    )


def apply_chart_style(figure: go.Figure) -> go.Figure:
    figure.update_layout(
        height=PLOT_HEIGHT,
        margin=dict(l=16, r=16, t=56, b=48),
        legend=dict(orientation="h", yanchor="top", y=-0.18, x=0),
        plot_bgcolor="white",
        paper_bgcolor="white",
        hovermode="x unified",
        font=dict(color="#31333F"),
        title=dict(font=dict(size=16, color="#31333F")),
    )
    figure.update_xaxes(showgrid=False, color="#31333F")
    figure.update_yaxes(gridcolor="#e5e7eb", zeroline=False, color="#31333F")
    return figure


def price_history_chart(prices: pd.DataFrame, test_start) -> go.Figure:
    """Closing price, 20-day moving average, and the start of the test period."""
    moving_average = prices["Close"].rolling(20).mean()
    figure = go.Figure()
    figure.add_trace(
        go.Scatter(
            x=prices["Date"],
            y=prices["Close"],
            name="Close",
            line=dict(color=ACTUAL_COLOR, width=2),
        )
    )
    figure.add_trace(
        go.Scatter(
            x=prices["Date"],
            y=moving_average,
            name="20-day moving average",
            line=dict(color="#64748b", width=1.8, dash="dot"),
        )
    )
    figure.add_vrect(
        x0=test_start,
        x1=prices["Date"].iloc[-1],
        fillcolor=TEST_COLOR,
        line_width=0,
        annotation_text="Test period",
        annotation_position="top left",
    )
    figure.update_layout(title="Closing price used for exploration")
    figure.update_yaxes(title="Close")
    return apply_chart_style(figure)


def actual_vs_predicted_chart(predictions: pd.DataFrame, model_name: str) -> go.Figure:
    figure = go.Figure()
    figure.add_trace(
        go.Scatter(
            x=predictions["Date"],
            y=predictions["actual_close"],
            name="Actual next close",
            line=dict(color=ACTUAL_COLOR, width=2.4),
        )
    )
    figure.add_trace(
        go.Scatter(
            x=predictions["Date"],
            y=predictions["predicted_close"],
            name="Predicted next close",
            line=dict(color=PREDICTED_COLOR, width=2.2),
        )
    )
    figure.update_layout(title=f"Actual vs predicted next close — {model_name}")
    figure.update_yaxes(title="Next close")
    return apply_chart_style(figure)


def scatter_chart(predictions: pd.DataFrame) -> go.Figure:
    actual = predictions["actual_close"]
    low = float(min(actual.min(), predictions["predicted_close"].min()))
    high = float(max(actual.max(), predictions["predicted_close"].max()))
    figure = go.Figure()
    figure.add_trace(
        go.Scatter(
            x=actual,
            y=predictions["predicted_close"],
            mode="markers",
            name="Test days",
            marker=dict(color=ACTUAL_COLOR, size=7, opacity=0.65),
        )
    )
    figure.add_trace(
        go.Scatter(
            x=[low, high],
            y=[low, high],
            mode="lines",
            name="Perfect prediction",
            line=dict(color=PREDICTED_COLOR, dash="dash"),
        )
    )
    figure.update_layout(title="Each test day: actual close against predicted close")
    figure.update_xaxes(title="Actual next close")
    figure.update_yaxes(title="Predicted next close")
    return apply_chart_style(figure)


def confusion_chart(matrix: list[list[int]]) -> go.Figure:
    """Direction check. Rows are what happened; columns are what the model said."""
    values = np.array(matrix, dtype=float)
    labels = ["DOWN", "UP"]
    figure = go.Figure(
        data=go.Heatmap(
            z=values,
            x=["Predicted DOWN", "Predicted UP"],
            y=["Actual DOWN", "Actual UP"],
            text=values.astype(int),
            texttemplate="%{text}",
            colorscale=[[0, "#f8fafc"], [1, "#93c5fd"]],
            showscale=False,
            textfont=dict(size=16, color="#0f172a"),
            hovertemplate="%{y}<br>%{x}<br>%{z} days<extra></extra>",
        )
    )
    figure.update_layout(
        title=dict(text="Direction check on the test period", font=dict(size=16, color="#31333F")),
        height=PLOT_HEIGHT,
        margin=dict(l=16, r=16, t=56, b=16),
        yaxis=dict(autorange="reversed"),
        paper_bgcolor="white",
        plot_bgcolor="white",
        font=dict(color="#31333F"),
    )
    figure.update_xaxes(showgrid=False, side="bottom")
    figure.update_yaxes(showgrid=False)
    del labels
    return figure


def mood_chart(history: pd.DataFrame, window: int) -> go.Figure:
    """Ten-day up-rate over time. 50% is an even split of up and down closes."""
    figure = go.Figure()
    figure.add_hline(y=0.5, line_dash="dot", line_color="#94a3b8", annotation_text="50%")
    figure.add_trace(
        go.Scatter(
            x=history["Date"],
            y=history["mood"],
            name=f"{window}-day up-rate",
            line=dict(color=ACTUAL_COLOR, width=2),
        )
    )
    figure.update_layout(title=f"Price mood: share of the last {window} closes that were up")
    figure.update_yaxes(title="Up-rate", tickformat=".0%", range=[0, 1])
    return apply_chart_style(figure)


def equity_chart(curve: pd.DataFrame, model_name: str) -> go.Figure:
    """Paper account that follows the model, against staying invested every day."""
    figure = go.Figure()
    figure.add_trace(
        go.Scatter(
            x=curve["Date"],
            y=curve["buy_hold_equity"],
            name="Buy and hold",
            line=dict(color=ACTUAL_COLOR, width=2.2),
        )
    )
    figure.add_trace(
        go.Scatter(
            x=curve["Date"],
            y=curve["strategy_equity"],
            name=f"Follow {model_name}",
            line=dict(color=PREDICTED_COLOR, width=2.2),
        )
    )
    figure.update_layout(title=f"Paper profit and loss on the test period — {model_name}")
    figure.update_yaxes(title="Account value")
    return apply_chart_style(figure)


def importance_chart(importances: pd.DataFrame) -> go.Figure:
    ordered = importances.sort_values("importance", ascending=True)
    figure = go.Figure(
        go.Bar(
            x=ordered["importance"],
            y=ordered["feature"],
            orientation="h",
            marker_color=ACTUAL_COLOR,
            hovertext=ordered["meaning"],
            hovertemplate="%{y}<br>%{hovertext}<br>importance %{x:.3f}<extra></extra>",
        )
    )
    figure.update_layout(title="Random Forest feature importance")
    figure.update_xaxes(title="Share of importance")
    return apply_chart_style(figure)


def class_confusion_chart(matrix: list[list[int]], labels: list[str], title: str) -> go.Figure:
    """Rows are what happened. Columns are what the classifier said."""
    values = np.array(matrix, dtype=float)
    figure = go.Figure(
        data=go.Heatmap(
            z=values,
            x=[f"Predicted {label}" for label in labels],
            y=[f"Actual {label}" for label in labels],
            text=values.astype(int),
            texttemplate="%{text}",
            colorscale=[[0, "#f8fafc"], [1, "#93c5fd"]],
            showscale=False,
            textfont=dict(size=16, color="#0f172a"),
            hovertemplate="%{y}<br>%{x}<br>%{z} days<extra></extra>",
        )
    )
    figure.update_layout(
        title=dict(text=title, font=dict(size=16, color="#31333F")),
        height=PLOT_HEIGHT,
        margin=dict(l=16, r=16, t=56, b=16),
        yaxis=dict(autorange="reversed"),
        paper_bgcolor="white",
        plot_bgcolor="white",
        font=dict(color="#31333F"),
    )
    figure.update_xaxes(showgrid=False, side="bottom")
    figure.update_yaxes(showgrid=False)
    return figure


def budget_path_chart(path: pd.DataFrame) -> go.Figure:
    """Average NIFTY move around the budget session, from five sessions before."""
    figure = go.Figure()
    figure.add_trace(
        go.Scatter(
            x=path["offset"],
            y=path["mean_return"],
            name="Average path",
            line=dict(color=ACTUAL_COLOR, width=2.4),
        )
    )
    figure.add_vline(x=0, line_dash="dot", line_color="#94a3b8")
    figure.update_layout(title="Average NIFTY path around the Union Budget session")
    figure.update_xaxes(title="Sessions relative to the budget session", dtick=1)
    figure.update_yaxes(title="Change from 5 sessions before", tickformat=".1%")
    return apply_chart_style(figure)


def verdict_banner(summary: dict) -> None:
    """Say whether the stronger learned classifier beat the majority baseline."""
    name = summary["best_name"]
    best = summary["best_accuracy"]
    majority = summary["majority_accuracy"]
    if summary["beats_majority"]:
        st.success(
            f"{name} has the highest accuracy among the learned models "
            f"and it beats the majority baseline ({best:.1%} vs {majority:.1%})."
        )
        return
    st.warning(
        f"{name} has the highest accuracy among the learned models "
        f"({best:.1%}), but it does not beat the majority baseline "
        f"({majority:.1%}) by more than one percentage point."
    )


def render_classification(packed: dict, chart_title: str, widget_key: str) -> None:
    """Accuracy table, the baseline verdict, and one confusion matrix."""
    metrics = packed["metrics"]
    display = metrics.copy()
    display["Accuracy"] = display["Accuracy"].map(lambda value: f"{value:.1%}")
    st.dataframe(display, hide_index=True)
    verdict_banner(packed["summary"])
    st.caption(
        f"Train {packed['train_start'].date()} → {packed['train_end'].date()} "
        f"({packed['train_rows']:,} days) · "
        f"Test {packed['test_start'].date()} → {packed['test_end'].date()} "
        f"({packed['test_rows']:,} days). "
        "A learned model is described as beating the baseline only when it leads "
        "by more than one percentage point."
    )
    model_names = list(packed["confusion"])
    default_index = model_names.index("Random Forest") if "Random Forest" in model_names else 0
    selected = st.selectbox(
        "Classifier to inspect",
        model_names,
        index=default_index,
        key=widget_key,
    )
    accuracy = float(metrics.loc[metrics["Model"] == selected, "Accuracy"].iloc[0])
    st.plotly_chart(
        class_confusion_chart(packed["confusion"][selected], packed["labels"], chart_title),
    )
    st.caption(f"Accuracy for {selected}: {accuracy:.1%}.")


def render_budget_study(source_name: str) -> None:
    """NIFTY case study. It does not depend on the dataset selected above."""
    st.subheader("Union Budget case study — NIFTY 50")
    st.markdown(
        f"""
The classifier above follows **{source_name}**. The case study below always
uses the bundled NIFTY 50 file, including when the sidebar shows another
series. Each speech date is mapped to the NIFTY session on that day, or to
the next open session within three calendar days.
        """
    )
    nifty_path = DATA_DIR / "NIFTY50.csv"
    if not nifty_path.exists() or not BUDGET_CALENDAR.exists():
        st.info(
            "The budget case study needs data/NIFTY50.csv and data/union_budgets.csv."
        )
        return
    try:
        study = prepare_budget_study(nifty_path.read_bytes(), BUDGET_CALENDAR.read_bytes())
    except Exception as exc:
        st.error(f"Could not build the budget case study. {exc}")
        return

    events = study["events"]
    mapped = events.dropna(subset=["session"]).copy()
    missed = int(events["session"].isna().sum())
    if mapped.empty:
        st.info("None of the speech dates fell on or just before a NIFTY session.")
        return

    display = pd.DataFrame(
        {
            "Announcement": mapped["announcement"].dt.strftime("%d %b %Y"),
            "Kind": mapped["kind"],
            "Session": mapped["session"].dt.strftime("%d %b %Y"),
            "Day return": mapped["day_return"].map(_signed_percent),
            "Volume vs average": (mapped["volume_ratio"] - 1.0).map(_signed_percent),
            "Label": mapped["label"].fillna("—"),
            "Next 5 sessions": mapped["next_5_return"].map(_signed_percent),
        }
    )
    st.dataframe(display, hide_index=True)
    counts = mapped["label"].fillna("Unknown").value_counts()
    count_text = ", ".join(f"{int(counts[label])} {label}" for label in counts.index)
    st.caption(
        f"{len(mapped)} speeches mapped to a session"
        + (f". {missed} could not be mapped." if missed else ".")
        + f" Labels on the session itself: {count_text}. "
        "Volume vs average is the session's volume compared with its own prior 20-day average. "
        "Next 5 sessions is the return from that session's close to the close five sessions later."
    )
    path = study["path"]
    st.plotly_chart(budget_path_chart(path))
    day_move = _path_return(path, 0)
    later_move = _path_return(path, 5)
    st.caption(
        f"Average of {study['path_count']} speeches with five sessions on each side. "
        f"The budget session closed {day_move} versus five sessions earlier, and five sessions "
        f"later the average close was {later_move} versus that same starting close. "
        "This describes these dates. It is not a forecast of the next budget."
    )


def _signed_percent(value) -> str:
    if pd.isna(value):
        return "—"
    return f"{float(value):+.2%}"


def _path_return(path: pd.DataFrame, offset: int) -> str:
    matches = path.loc[path["offset"] == offset, "mean_return"]
    if matches.empty or pd.isna(matches.iloc[0]):
        return "unavailable"
    return f"{float(matches.iloc[0]):+.2%}"


def sidebar_controls() -> tuple[str, float, int, object]:
    st.sidebar.subheader("Project settings")
    dataset_key = st.sidebar.selectbox(
        "Bundled dataset",
        options=list(BUNDLED_DATASETS),
        format_func=lambda key: BUNDLED_DATASETS[key],
    )
    test_size = st.sidebar.slider(
        "Test set size",
        min_value=0.10,
        max_value=0.40,
        value=0.20,
        step=0.05,
        help="The most recent fraction of trading days is held out for testing.",
    )
    seed = st.sidebar.number_input("Random seed", min_value=0, max_value=9999, value=42, step=1)
    test_size = round(float(test_size), 2)
    st.sidebar.markdown("**Expected CSV columns:**")
    st.sidebar.caption("Date, Open, High, Low, Close, Volume")
    st.sidebar.caption(
        "The split is chronological. The model is never trained on dates that fall inside the test period."
    )
    return dataset_key, float(test_size), int(seed)


def render_algorithm() -> None:
    left, right = st.columns(2)
    with left:
        st.markdown("**Linear Regression, in one minute**")
        st.markdown(
            """
Linear Regression looks for one weight per feature. The forecast is a weighted
sum:

`next-day return = w1·return_1 + w2·ma_5_ratio + … + b`

The weights are chosen so the squared error on the training days is as small
as possible. A positive weight means "when this feature is higher, the model
expects a higher next-day return." It is easy to write on a board. It can only
draw a straight relationship, so it is the baseline.
            """
        )
    with right:
        st.markdown("**Random Forest, in one minute**")
        st.markdown(
            """
A decision tree asks a chain of yes/no questions, such as "is 10-day
volatility above 2%?" and ends at a predicted return. One tree memorises the
training days. A random forest grows hundreds of trees. Each tree sees a
random sample of the rows and a random subset of the features. The forest's
forecast is the average of the trees, which is more stable than any single
tree. Depth is limited to 6 so a tree cannot grow until it memorises every day.
            """
        )
    st.markdown(
        """
**How to read the scores.** RMSE and MAE are in price units (dollars for the
US stocks, index points for NIFTY). Smaller is closer to the real next close.
The naive model predicts a return of zero, so its predicted close is simply
today's close. A learned model is useful only when its RMSE is smaller than
that naive RMSE. Direction accuracy near 50% is a coin flip: say so if that is
what the table shows. Markets are noisy, and this is not a trading system.
        """
    )


def main() -> None:
    dataset_key, test_size, seed = sidebar_controls()

    st.title("Stock Price Prediction — Model Comparison")
    st.markdown(
        "<p style='color:#6b7280; margin-top:-12px;'>"
        "Educational machine learning demonstration. It is not financial advice."
        "</p>",
        unsafe_allow_html=True,
    )
    st.markdown("Optional: upload your stock CSV dataset")
    uploaded = st.file_uploader(
        "Upload a CSV with Date, Open, High, Low, Close, and Volume",
        type=["csv"],
        label_visibility="collapsed",
    )

    if uploaded is not None:
        csv_bytes = uploaded.getvalue()
        source_name = uploaded.name
    else:
        try:
            csv_bytes = read_bundled(dataset_key)
        except FileNotFoundError as exc:
            st.error(f"Could not prepare/train the project. {exc}")
            st.info(
                "Upload a CSV containing Date, Open, High, Low, Close, and Volume."
            )
            return
        source_name = BUNDLED_DATASETS[dataset_key]

    with st.spinner("Preparing features and training the comparison..."):
        try:
            project = prepare_project_full(csv_bytes, test_size, seed)
        except Exception as exc:
            st.error(f"Could not prepare/train the project. {exc}")
            st.info(
                "Upload a CSV containing Date, Open, High, Low, Close, and Volume. "
                "The file needs at least a few months of daily rows."
            )
            return

    summary = project["summary"]
    train = project["train"]
    test = project["test"]
    metrics = project["metrics"]

    st.caption(f"Source: {source_name}")

    # ------------------------------------------------------------------
    # 1. Data collection and exploration
    # ------------------------------------------------------------------
    st.header("1. Data collection and exploration")
    st.markdown(
        """
The bundled files are daily prices from Yahoo Finance, saved in `data/` so
this page works without an internet connection. Apple, Tesla, and Microsoft
use the adjusted close, which removes the artificial jump caused by a stock
split. NIFTY 50 is the index level.
        """
    )
    c1, c2, c3, c4 = st.columns(4)
    c1.metric("Trading days", f"{summary['rows']:,}")
    c2.metric("From", summary["start"].strftime("%d %b %Y"))
    c3.metric("To", summary["end"].strftime("%d %b %Y"))
    c4.metric("Missing values", f"{summary['missing_values']}")
    st.plotly_chart(
        price_history_chart(project["prices"], test["Date"].iloc[0]),
    )
    st.caption(
        "The shaded band is the test period. Everything to the left of it is used for training."
    )

    # ------------------------------------------------------------------
    # 2. Preprocessing and feature engineering
    # ------------------------------------------------------------------
    st.header("2. Preprocessing and feature engineering")
    st.markdown(
        """
Rows are sorted by date and duplicate dates are removed. The target is the
**next day's percentage return**, not the price level:

`target = (tomorrow's close − today's close) / today's close`

Moving averages are turned into a ratio (`close / moving average − 1`) so the
feature describes today's price relative to its recent average. The same idea
is used for the open-close difference and the high-low range. The first rows
do not have a full 20-day window, and the last row has no tomorrow, so those
rows are dropped. No future value is used as a feature.
        """
    )
    preview_columns = ["Date", "Close", *FEATURE_COLUMNS, "target_return"]
    preview = project["featured"][preview_columns].head(8).copy()
    preview["Date"] = pd.to_datetime(preview["Date"]).dt.strftime("%Y-%m-%d")
    st.dataframe(preview, hide_index=True)
    with st.expander("What each feature means"):
        meaning_table = pd.DataFrame(
            {
                "Feature": FEATURE_COLUMNS,
                "Meaning": [FEATURE_MEANINGS[name] for name in FEATURE_COLUMNS],
            }
        )
        st.dataframe(meaning_table, hide_index=True)

    # ------------------------------------------------------------------
    # 3. Train-test split
    # ------------------------------------------------------------------
    st.header("3. Train-test split")
    st.markdown(
        f"""
The rows stay in date order. The last **{test_size:.0%}** of days form the
test set. The random seed ({seed}) only affects the random forest. It does
not shuffle time.
        """
    )
    s1, s2, s3 = st.columns(3)
    s1.metric(
        "Training days",
        f"{len(train):,}",
        help=f"{train['Date'].iloc[0].date()} to {train['Date'].iloc[-1].date()}",
    )
    s2.metric(
        "Test days",
        f"{len(test):,}",
        help=f"{test['Date'].iloc[0].date()} to {test['Date'].iloc[-1].date()}",
    )
    s3.metric(
        "Test starts",
        test["Date"].iloc[0].strftime("%d %b %Y"),
    )
    st.caption(
        f"Train {train['Date'].iloc[0].date()} → {train['Date'].iloc[-1].date()}"
        f" · Test {test['Date'].iloc[0].date()} → {test['Date'].iloc[-1].date()}"
    )

    # ------------------------------------------------------------------
    # 4 and 5. Models and evaluation
    # ------------------------------------------------------------------
    st.header("4. Model building and evaluation")
    st.markdown(
        """
Three forecasts are scored on the same test days.

- **Naive (no change)** predicts that tomorrow's close equals today's close.
- **Linear Regression** fits one weight per feature.
- **Random Forest** averages 300 shallow decision trees.

The predicted return is converted back into a price with
`predicted close = today's close × (1 + predicted return)`, which is what the
chart and the price RMSE use.
        """
    )
    display_metrics = metrics.copy()
    display_metrics["Direction accuracy"] = display_metrics["Direction accuracy"].map(
        lambda value: f"{value:.1%}"
    )
    st.dataframe(
        display_metrics,
        hide_index=True,
        column_config={
            "RMSE (price)": st.column_config.NumberColumn(format="%.2f"),
            "MAE (price)": st.column_config.NumberColumn(format="%.2f"),
            "RMSE (return)": st.column_config.NumberColumn(format="%.4f"),
            "MAE (return)": st.column_config.NumberColumn(format="%.4f"),
            "R² (return)": st.column_config.NumberColumn(format="%.3f"),
        },
    )

    naive_rmse = float(metrics.loc[metrics["Model"] == "Naive (no change)", "RMSE (price)"].iloc[0])
    learned = metrics[metrics["Model"] != "Naive (no change)"]
    best_name = learned.loc[learned["RMSE (price)"].idxmin(), "Model"]
    best_rmse = float(learned["RMSE (price)"].min())
    if best_rmse < naive_rmse:
        st.success(
            f"{best_name} has the lowest price RMSE among the learned models "
            f"and it beats the no-change baseline ({best_rmse:.2f} vs {naive_rmse:.2f})."
        )
    else:
        st.warning(
            f"{best_name} has the lowest price RMSE among the learned models "
            f"({best_rmse:.2f}), but the no-change baseline is closer "
            f"({naive_rmse:.2f}). That is a normal result for next-day prices: "
            "most of tomorrow's price is already contained in today's price."
        )

    # ------------------------------------------------------------------
    # 6. Actual vs predicted
    # ------------------------------------------------------------------
    st.header("5. Actual vs predicted")
    model_names = list(project["predictions"])
    default_index = model_names.index("Random Forest")
    selected = st.selectbox("Model to plot", model_names, index=default_index)
    predictions = project["predictions"][selected]
    st.plotly_chart(
        actual_vs_predicted_chart(predictions, selected),
    )
    st.caption(
        "The two lines stay close even for the naive forecast, because tomorrow's "
        "close is near today's close. Use the RMSE table, not the overlap alone, "
        "when you say how good the model is."
    )
    chart_left, chart_right = st.columns(2)
    with chart_left:
        st.plotly_chart(scatter_chart(predictions))
    with chart_right:
        st.plotly_chart(
            confusion_chart(project["confusion"][selected]),
        )
        accuracy = float(metrics.loc[metrics["Model"] == selected, "Direction accuracy"].iloc[0])
        st.caption(
            f"Direction accuracy for {selected}: {accuracy:.1%}. "
            "UP means the next close is higher than today's close."
        )

    # ------------------------------------------------------------------
    # 7. Mood and paper profit
    # ------------------------------------------------------------------
    st.header("6. Business read: mood and paper profit")
    mood = market_mood(project["prices"])
    account = paper_trading(predictions, starting_capital=STARTING_CAPITAL)
    st.markdown(
        f"""
**Price mood** is the share of the last {mood['window']} sessions that closed
higher than the day before. It uses only past closes. It is not a reading of
news or social media.

**Paper profit** replays the test period. When **{selected}** predicts an up
day, a notional {STARTING_CAPITAL:,.0f} stays invested and earns that day's
real return. Otherwise it sits in cash. A predicted return of zero, which is
what the no-change model always says, counts as cash, so that account never
invests. Buy-and-hold stays invested every test day. There are no fees and no
slippage. This is a what-if on days that already happened, not a promise of
future profit.
        """
    )
    mood_col, profit_col, hold_col, days_col = st.columns(4)
    mood_col.metric("Price mood", f"{mood['latest']:.0%}", mood["label"])
    profit_col.metric(
        f"Follow {selected}",
        f"{account['ending_strategy']:,.0f}",
        f"{account['profit_strategy']:+,.0f} vs start",
    )
    hold_col.metric(
        "Buy and hold",
        f"{account['ending_buy_hold']:,.0f}",
        f"{account['profit_buy_hold']:+,.0f} vs start",
    )
    days_col.metric(
        "Days invested",
        f"{account['days_invested']:,} of {account['test_days']:,}",
    )
    strategy_end = round(account["ending_strategy"], 2)
    hold_end = round(account["ending_buy_hold"], 2)
    if strategy_end > hold_end:
        st.success(
            f"Following {selected} finished higher than buy-and-hold "
            f"({account['ending_strategy']:,.0f} vs {account['ending_buy_hold']:,.0f})."
        )
    elif strategy_end == hold_end:
        st.info(
            f"The two accounts finished at the same value ({account['ending_strategy']:,.0f})."
        )
    else:
        st.warning(
            f"Buy-and-hold finished higher "
            f"({account['ending_buy_hold']:,.0f} vs {account['ending_strategy']:,.0f}). "
            "A close price chart can look accurate while the business result does not."
        )
    st.plotly_chart(mood_chart(mood["history"], mood["window"]))
    st.caption(
        f"Latest reading: {mood['latest']:.0%} of the last {mood['window']} closes were up, "
        f"so the label is {mood['label']}. "
        "60% or more is Bullish, 40% to 60% is Mixed, and under 40% is Bearish."
    )
    st.plotly_chart(equity_chart(account["curve"], selected))
    st.caption(
        "Both lines start at "
        f"{STARTING_CAPITAL:,.0f}. "
        "Dollars for the US stocks, and the same notional applied to index returns for NIFTY."
    )

    # ------------------------------------------------------------------
    # 8. Explanation and what the model used
    # ------------------------------------------------------------------
    st.header("7. How the algorithms work")
    render_algorithm()

    st.subheader("What the Random Forest relied on")
    st.plotly_chart(importance_chart(project["importances"]))
    with st.expander("Linear Regression coefficients (after scaling each feature)"):
        st.markdown(
            "Each feature was scaled on the training set to have mean 0 and "
            "standard deviation 1. A coefficient of 0.01 means: if that feature "
            "is one standard deviation higher, the predicted next-day return "
            "increases by 1 percentage point."
        )
        st.dataframe(project["coefficients"], hide_index=True)

    # ------------------------------------------------------------------
    # 8. Bullish or bearish over the next 10 sessions
    # ------------------------------------------------------------------
    st.header("8. Bullish or bearish")
    regime = project["regime"]
    st.markdown(
        f"""
The price model asks about the next session. This training asks a wider
question: will the close **{regime['horizon']} sessions** from today be higher
than today's close?

**Bullish** means that return is positive. **Bearish** means it is not. The
inputs are the same ten features, all known at today's close. The last
{regime['horizon']} sessions have no answer yet, so they are left out of the
accuracy. The split is the same chronological cut as the price model.

- **Majority class** always guesses the label that was more common on the training days.
- **Logistic Regression** turns a weighted sum of the features into a probability for each label.
- **Random Forest** averages 300 shallow trees and takes the more likely label.

A learned model is useful here only when its accuracy is clearly above the majority baseline. This is a classroom forecast, not a trading signal.
        """
    )
    render_classification(regime, "Bullish or bearish on the test period", "regime-model")
    latest = regime["latest"]
    call_col, probability_col = st.columns(2)
    call_col.metric("Latest call", latest["label"])
    probability_col.metric("Forest probability", f"{latest['probability']:.0%}")
    if latest["scored"]:
        st.caption(
            f"As of {latest['date'].strftime('%d %b %Y')}, the realized label was "
            f"{latest['actual']}. That day already has its {regime['horizon']} following sessions, "
            "so it can sit inside the scored history."
        )
    else:
        st.caption(
            f"As of {latest['date'].strftime('%d %b %Y')}. The next {regime['horizon']} sessions "
            "are not finished, so this call is not in the accuracy score."
        )

    # ------------------------------------------------------------------
    # 9. Entry, exit, and the Union Budget case study
    # ------------------------------------------------------------------
    st.header("9. Entries, exits, and the Union Budget")
    st.markdown(
        """
Public prices do not name the people who bought or sold. A finished session
is labeled from its own close and from its volume compared with that volume's
20-day average:

- **Entry** — the close rose, and volume was at least the recent average.
- **Exit** — the close fell, and volume was at least the recent average.
- **Quiet** — volume was below that average.

The classifier predicts **tomorrow's** label. Today's close and today's volume
are allowed in only as today's features. They are not the answer. Yahoo's
volume figure compares how busy one day was with another. It is not a headcount
of investors. A zero-volume day is Quiet, because it sits below the recent average.

The budget block underneath is a case study. It is not a model fit on a dozen speeches.
        """
    )
    render_classification(
        project["participation"],
        "Entry, exit, or quiet on the test period",
        "participation-model",
    )
    render_budget_study(source_name)


main()
