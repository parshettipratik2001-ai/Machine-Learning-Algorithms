# Stock Price Prediction — Study and Presentation Guide

This note is for presenting the project. Read it once with the app open (`python -m streamlit run app.py`), then practice the opening out loud. The numbers below are the default run: Apple, test size 0.20, random seed 42.

---

## 1. Project Overview (the opening)

Memorize this. It is the first thing to say.

> We built a machine-learning project that looks at a stock's recent daily prices and estimates tomorrow's closing price. The data is public daily history for Apple, Tesla, Microsoft, and the NIFTY 50, from 2015 to late 2026. The model learns from past days only, and we test it on the most recent days, which it has never seen. The honest result is that the forecast stays close to today's price, and it does not reliably beat the simple guess "tomorrow will look like today."

If they ask for one more sentence:

> That result is useful. It shows a correct pipeline, and it shows why a chart of stock prices can look accurate even when the model has not learned the next move.

---

## What we used

Keep this high level. Name the idea, then the tool, then stop.

### The ideas

- **Supervised learning.** Each past day has inputs (what we knew at the close) and an answer (the next day's move). The model studies those pairs, then is marked on later days.
- **Regression.** The answer is a number, the next-day percent change, not a category. Up or down is only a check we derive from that number.
- **Time-series split.** The last 20% of dates are the exam. The rows are never shuffled, so the model cannot study the future.
- **Linear regression.** One weight per input. A straight-line summary of the training days. Easy to explain, and the simple learned baseline.
- **Random forest.** Many short decision trees, averaged. The main model. Averaging stops one tree from memorizing old days.
- **No-change baseline.** Tomorrow's close equals today's close. Every learned model has to beat this before anyone calls it useful.
- **Error measures.** RMSE and MAE say how far the predicted price was from the real price. Direction accuracy says how often up versus down was right.

### The Python libraries

The language is Python. Each library does one job.

| Library | What we use it for |
| --- | --- |
| **pandas** | The tables: load the CSV, sort the dates, build the columns |
| **NumPy** | The arithmetic underneath the tables and the scores |
| **scikit-learn** | Linear regression, the random forest, and the scores (RMSE, MAE, R², accuracy, confusion matrix) |
| **yfinance** | The optional download from Yahoo Finance. The demo itself uses the saved CSV files |
| **Streamlit** | The web page used in the presentation |
| **Plotly** | The interactive charts on that page |
| **Matplotlib** and **Seaborn** | The same charts in the notebook |

One sentence if they ask how the pieces fit: pandas prepares the table, scikit-learn fits and scores the models, and Streamlit with Plotly shows the result.

---

## 2. Dataset and features

### Where the data comes from

Each file in `data/` is one series of daily prices downloaded from Yahoo Finance.

| File | What it is | Rows | Dates |
| --- | --- | ---: | --- |
| `AAPL.csv` | Apple share price | 2,989 | 2 Jan 2015 – 19 Nov 2026 |
| `TSLA.csv` | Tesla share price | 2,989 | same window |
| `MSFT.csv` | Microsoft share price | 2,989 | same window |
| `NIFTY50.csv` | NIFTY 50 index | 2,926 | 2 Jan 2015 – 20 Nov 2026 |

`Close` for the three US stocks is the **adjusted close**. A stock split cuts the share price in half on paper even though nothing bad happened to the company. Adjusted prices remove that fake jump, so the model does not treat a split as a crash.

A friend can upload another CSV. It needs the columns Date, Open, High, Low, Close, and Volume.

### The six columns that arrive in the file

Think of one row as one trading day.

- **Date** — which day this row is. Order matters. We sort by this column.
- **Open** — the first price of the day.
- **High** — the highest price during the day.
- **Low** — the lowest price during the day.
- **Close** — the last price of the day. This is the price people mean when they say "Apple closed at 349."
- **Volume** — how many shares (or, for NIFTY, how much activity) changed hands. A quiet day and a frantic day can have the same close. Volume tells them apart.

### What we ask the model to predict

We do **not** ask "what number will the price be?" as the raw target.

We ask: **by what percent will the close change from today to tomorrow?**

```text
target return = (tomorrow's close - today's close) / today's close
```

Then we turn that percent back into a price for the chart:

```text
predicted close = today's close × (1 + predicted return)
```

Analogy: predicting tomorrow's temperature by predicting "two degrees warmer than today" is a cleaner question than predicting the temperature from scratch. Most of tomorrow's price is already sitting in today's price. If we scored a model on the price level alone, a model that simply repeats today's close would look brilliant.

### The ten features the model is allowed to see

Every feature on a row is known **when that day's market closes**. None of them peek at tomorrow. That rule is called "no leakage," and it is the rule a professor will care about most.

**Recent returns — has the price been rising or falling?**

- `return_1` — today's percent change versus yesterday. One day of momentum.
- `return_5` — percent change over the last 5 trading days. About one week.
- `return_10` — percent change over the last 10 trading days. About two weeks.

Why they might help: sometimes a move continues for a few days, and sometimes it snaps back. The model is allowed to check whether recent direction says anything about tomorrow. On this data, the link is weak.

**Moving-average ratios — is today expensive or cheap compared with the recent average?**

A moving average is the average closing price over the last few days. The 5-day moving average is "the typical close this week."

We do not hand the model the average itself, because that number is just another price level (100, 200, 300) and those levels drift upward for years. We hand it a ratio:

```text
ma_5_ratio  = today's close / 5-day average  - 1
ma_10_ratio = today's close / 10-day average - 1
ma_20_ratio = today's close / 20-day average - 1
```

A value of `0.02` means today's close is 2% above that average. A value of `-0.01` means it is 1% below. Positive means "running hot." Negative means "running cold." Traders look at this constantly. The model gets the same clue, in a form that stays meaningful in 2015 and in 2026.

**How wild the market has been**

- `volatility_10` — the standard deviation of daily returns over the last 10 days.

Analogy: the average daily move might be small, but some fortnights are calm and some are stormy. This feature measures the storm. On Apple it is the feature the random forest relies on most.

**What happened inside today**

- `oc_diff` = `(close - open) / open`. Did the day finish above where it started, and by how much? A day that opens weak and closes strong is a different story from a day that does the opposite, even if the close is the same.
- `hl_range` = `(high - low) / close`. How wide was today's swing, relative to the price? A wide range means the market argued with itself. A narrow range means agreement.

**Was today busier than yesterday?**

- `volume_change` — percent change in volume versus the previous day. A price jump on huge volume is a louder event than the same jump on tiny volume.

### Rows we throw away

The 20-day average does not exist for the first 19 days. The last day has no "tomorrow," so it has no target. Those rows are dropped. Apple goes from 2,989 raw days to 2,969 usable days. Missing prices are dropped as well. In these four files, the missing-value count is zero after loading.

---

## 3. Step-by-step build

Walk the app from section 1 to section 6. That order is the pipeline.

### Step 1 — Load and look

`load_prices` reads the CSV, accepts `Date` / `Open` / `High` / `Low` / `Close` / `Volume` even if the capital letters differ, prefers an adjusted close when both exist, parses dates, forces the price columns to be numbers, sorts by date, and deletes duplicate dates.

Then we look before we model. Apple has 2,989 days, no missing values, and a last close of about 349 dollars. The daily return averages about 0.11% with a typical swing of about 1.8%. The price chart shows a long rise, a 20-day moving average through it, and an orange band on the right. That band is the test period.

What to say: "I explored the series before training, so I know the dates, the gaps, and the shape of the price."

### Step 2 — Build the features and the target

`engineer_features` adds the ten features above and the next-day return. Rolling averages and percent changes look **backward only**. The only place the future appears is the target, via a one-day shift:

```text
target_return = tomorrow's percent change, written onto today's row
next_close    = tomorrow's close, kept so we can score the price later
```

The last row is dropped because that shift has nothing to copy into it.

What to say: "The inputs are today's information. The answer key is tomorrow. We never put the answer key into the inputs."

### Step 3 — Split by time, and do not shuffle

A normal machine-learning tutorial shuffles the rows, then takes a random 20% as the test. That is correct for photos of cats and dogs. It is wrong for a calendar.

If we shuffle stock days, the model can train on March and be tested on January. It has already seen the future of the test day. The score becomes a lie. The name for that lie is **data leakage**.

Our split keeps the rows in date order:

- **Train:** the earliest 80% — Apple, 30 Jan 2015 to 9 Jul 2024 — 2,375 days. The model may learn from these.
- **Test:** the latest 20% — Apple, 10 Jul 2024 to 18 Nov 2026 — 594 days. The model is marked on these, and it never saw them during training.

The slider in the sidebar changes that 20%. The random seed (42) only changes the randomness inside the forest. It does not shuffle time.

Analogy: a fair exam uses questions from after the study period. Shuffling would let you revise with the question paper already in the pile.

### Step 4 — Train three forecasts on the same days

All three see the same training rows and are scored on the same test rows.

1. **Naive (no change).** Predicted return = 0. Predicted close = today's close. This model learns nothing. It is the bar.
2. **Linear regression.** One weight per feature. Details are in the next section. The features are rescaled using the training days only, inside a pipeline, so the test days do not influence the scaling.
3. **Random forest.** 300 short decision trees, averaged. This is the model to explain.

### Step 5 — Score them

For every test day we compare the predicted next close with the real next close, and we also check whether we got the direction (up or down) right. Section 5 of this guide is how to talk about those numbers.

### Step 6 — Show the pictures

The line chart, the scatter plot, the direction grid, and the feature-importance bars. Section 5 says what to point at.

---

## 4. How the model works

The presentation compares two learning methods. Explain linear regression in four sentences, then spend the time on the random forest. The forest is the main model. Linear regression is there so we can say "a straight-line model is not enough, and a more flexible model still does not find a reliable next-day edge."

### Linear regression, as a weighing scale

Imagine tomorrow's return is a weighing scale. Each feature is an object you put on it, and each object has a weight the model is allowed to choose.

```text
predicted return = w1×return_1 + w2×ma_5_ratio + ... + a constant
```

Training means: try weights, measure how far the guesses are from the real next-day returns on the training days, and keep the weights that make the total squared error as small as possible. Squared error means a miss of 2 hurts more than two misses of 1. Big surprises count extra.

A positive weight means "when this feature is higher, I expect a higher return tomorrow." Before fitting, each feature is stretched to have an average of 0 and a typical size of 1, using the training days only. After that, the weights are comparable: a weight of 0.01 means "one typical step up in this feature adds about 1 percentage point to the predicted return."

The limit is the shape. Linear regression can only draw a straight relationship. If a calm market and a stormy market need opposite rules, one straight weight cannot say both.

### Random forest, as a committee of short quizzes

A **decision tree** is a flowchart of yes/no questions.

> Is 10-day volatility high?
> If yes: is today's range wide?
> If no: is the price above its 20-day average?
> ...and at the end of the path, a predicted return.

One deep tree can memorize the training days. It gets those days almost perfect and then fails on new days. That failure mode is called overfitting: the model learned the names of the old days instead of a rule that travels.

A **random forest** grows many trees and averages them, the way a committee vote is steadier than one loud person.

Our forest has:

- **300 trees.** A large committee.
- **Depth capped at 6.** Each quiz is short, so one tree cannot ask enough questions to memorize a single day.
- **At least 5 training days in every final leaf.** A prediction must be based on a small group of similar days, not one freak day.
- **A random sample of rows for each tree,** and a **random subset of features at each question.** The trees disagree with each other on purpose. Averaging the disagreements is what makes the committee stable.

The seed 42 makes that randomness repeatable. Same seed, same forest. It does not shuffle the calendar.

Why this pair, and not a neural network: both models can be drawn on a board. A professor can ask "what does this weight mean?" or "what question is this tree asking?" and there is a plain answer. The task is also a small table of a few thousand days and ten features. A huge neural net is the wrong tool for a table that size, and it is harder to defend in a viva. Section 6 has the longer version of that answer.

On Apple, the forest's largest votes go to 10-day volatility, the 10-day average ratio, the day's range, and the 20-day average ratio. Say "it paid most attention to how jumpy the recent market was, and to whether the price sat above its recent average." Do not claim those features caused the next move. Importance means "the trees used this column a lot," not "this column predicts the market."

---

## 5. Understanding the results and the graphs

Use the Apple table unless you have switched the sidebar to NIFTY. Read the banner under the table before you describe the model as good or bad.

### Apple test scores (10 Jul 2024 – 18 Nov 2026, 594 days)

| Model | RMSE (dollars) | MAE (dollars) | Direction accuracy |
| --- | ---: | ---: | ---: |
| Naive (no change) | 4.29 | 2.96 | 46.3% |
| Linear regression | 4.33 | 2.98 | 51.0% |
| Random forest | 4.37 | 3.00 | 52.2% |

NIFTY, same settings, in index points: the forest's RMSE is 201.06 against a naive RMSE of 201.60, and its direction accuracy is 54.3%. That is a small edge on one index. Say "small," and then go back to the idea below.

### What each number means

**RMSE (price).** Root mean squared error. Take each test day's price error, square it, average those squares, then take the square root. The result is in dollars (or index points). Squaring makes a few terrible days count more. Lower is closer to the truth. On Apple, a typical "punished" error is about 4.3 dollars on a share that traded around 200–350 dollars in the test window. The naive guess is the best of the three.

**MAE (price).** Mean absolute error. The average of the absolute misses, in dollars, with no extra punishment for big days. About 3 dollars. Easier to say out loud than RMSE: "on an average test day we were off by about 3 dollars." Again the naive guess wins.

**R² on the return.** How much of the up-and-down in the next-day percent the model explains. Zero means "no better than guessing the average return." Negative means "worse than guessing the average." Ours is about zero or slightly negative. Say that. Do not quote R² on the price level. That number looks excellent for a bad reason: the price level is slow, so even a copy of yesterday scores high.

**Direction accuracy.** The share of test days where we correctly said the next close would be higher, or not higher. A flat prediction counts as "not up." A coin flip is about 50%.

There is a trap in the 52% figure. On the Apple test set the market rose on 319 of 594 days, which is **53.7%**. A person who always says "up" scores 53.7%. The forest scores 52.2%. So 52% is not a discovered edge. It is slightly worse than always being optimistic during a rising market.

The confusion grid shows why. For the Apple forest, reading rows as what happened and columns as what we said:

|  | We said DOWN | We said UP |
| --- | ---: | ---: |
| Market went DOWN | 47 | 228 |
| Market went UP | 56 | 263 |

The forest said UP on 491 of 594 days. It is a mild optimist. Point at the large right-hand column and say: "Most of its calls are UP. That matches a rising test period, and it is why a 52% direction score is not impressive."

The naive row of the grid is even more lopsided: every prediction is DOWN, because a predicted return of exactly zero is counted as "not up." Its 46.3% is simply the share of test days that fell. Do not describe the naive model as a clever down-picker. It never makes a direction call. Use it for the price RMSE, where "tomorrow equals today" is a serious forecast.

### What to point at on the charts

**Line chart — actual next close against predicted next close.** The two lines hug each other. Pause before anyone says "the model is excellent." Say this sentence:

> The lines are close because tomorrow's price is near today's price. The no-change forecast draws almost the same picture. The RMSE table is the real score, and on Apple the no-change forecast wins.

**Scatter plot — each test day as a dot.** Horizontal axis: real next close. Vertical axis: predicted next close. The dashed line is a perfect call. Dots sit on that line because the level is easy, not because the daily move was forecast. If the model had truly learned the move, the dots would still be near the line, but the RMSE would beat the naive model. It does not.

**Orange band on the exploration chart.** Everything left of the band is study material. Everything inside the band is the exam. The cut is 10 July 2024 for the default Apple run.

**Feature-importance bars.** These are the forest's habits, not a trading signal. On Apple, lead with volatility and the moving-average ratios.

### A sentence that makes you sound careful

> I would trust this project as a demonstration of a leakage-free pipeline. I would not trust it as a forecast of tomorrow's Apple close.

---

## Business read: mood and paper profit

This is the part to use with a business-analytics audience. It does not add a new model. It asks two business questions of the model you already have.

### Price mood

Mood is the share of the last 10 sessions that closed higher than the day before. It uses only closes that have already happened. It is not news sentiment and it is not social-media sentiment.

- 60% or more: Bullish
- 40% to 60%: Mixed
- under 40%: Bearish

On the bundled Apple file the latest reading is **40%, Mixed**: four of the last ten closes were up. Say: "The recent tape is balanced, not a strong trend." If the file is refreshed, re-read the number from the app. Do not memorize 40% as a permanent fact about Apple.

### Paper profit and loss

Replay the test period with a notional 10,000. No fees and no slippage.

- If the model predicts an up day, the account holds for the next session and earns the real return.
- If it predicts flat or down, the account sits in cash.
- Buy-and-hold stays invested every test day.

The no-change model always predicts a return of zero, so its paper account never invests and finishes at 10,000. That is not a clever cash strategy. It never makes an up call.

Default Apple test, 594 days:

| Account | Ending value | Profit | Days invested |
| --- | ---: | ---: | ---: |
| Start | 10,000 | — | — |
| Follow the random forest | 13,244 | +3,244 | 491 of 594 |
| Follow linear regression | 11,381 | +1,381 | 498 of 594 |
| Buy and hold | 15,143 | +5,143 | 594 of 594 |

The forest made a paper profit and still lost to simply holding the stock. Point at the two equity lines and say:

> Following the model grew 10,000 to about 13,200. Holding the stock grew it to about 15,100. The business result agrees with the RMSE table: the model does not beat staying invested. This is a replay of the test days, not a promise of future profit.

---

## Two more trainings

These are sections 8 and 9 of the app. They use the same ten features and the same rule: nothing on the row is allowed to see the future. The split is still the last 20% of dates. The new baseline is the **majority class**: always guess the label that was more common on the training days. Say a learned model beats that baseline only when it leads by more than one percentage point. A smaller gap is too close to present as a win.

The price-mood label higher up the page is not this training. Mood describes the last 10 closes that already happened. This training tries to call the next 10.

### Bullish or bearish

The question: will the close 10 sessions from today be higher than today's close?

- **Bullish** — that 10-session return is positive.
- **Bearish** — it is not.

The last 10 sessions have no answer yet, so they are left out of the accuracy. Logistic regression and a random forest classifier (300 trees, depth capped at 6) are fit on the training days only. The logistic model is scaled inside a pipeline, on the training rows only.

Default Apple run, test size 0.20, seed 42. Test window 28 June 2024 to 5 November 2026, 592 days:

| Model | Accuracy |
| --- | ---: |
| Majority class | 57.9% |
| Logistic regression | 54.7% |
| Random forest | 56.9% |

The forest does not beat the majority baseline. What to say:

> On Apple, the common training label already scores about 58% on the later days. The forest scores about 57%. I do not have a 10-day bullish or bearish signal. The latest close, 19 November 2026, is called Bullish with about a 57% forest probability, and that call is unscored because the next 10 sessions are not finished.

If the file is refreshed, read the latest call from the app. Do not memorize 19 November as a permanent fact.

### Entries, exits, and the Union Budget

Public prices do not name the people who bought or sold. Say that sentence before the table. A finished session gets a label from its own close and from its volume compared with that volume's 20-day average:

- **Entry** — the close rose, and volume was at least the recent average.
- **Exit** — the close fell, and volume was at least the recent average.
- **Quiet** — volume was below that average. A zero-volume day lands here.

The classifier predicts **tomorrow's** label. Today's close and today's volume are allowed in only as today's features. Yahoo's volume figure is a way to compare how busy two days were. It is not a headcount of investors.

Default Apple test, the same 594 days as the price model:

| Model | Accuracy |
| --- | ---: |
| Majority class | 64.0% |
| Logistic regression | 64.1% |
| Random forest | 64.0% |

What to say:

> Most test days are the majority label, so 64% sounds strong and is not. Logistic regression leads by about a tenth of a point. That is not a model of investors entering and leaving Apple.

On NIFTY, with the same settings, the forest scores about 58.7% against a majority baseline of about 57.3%. That is a lead of roughly one point. Call it a small edge on one series, the same way you talk about NIFTY's small price-RMSE edge. It is not evidence that the model saw who traded.

The budget block always uses the bundled NIFTY file, even when the sidebar is Apple. It is a case study of 14 Union Budget speeches from 2015 through 2026, including the interim budgets of 1 February 2019 and 1 February 2024 and the full budgets of 5 July 2019 and 23 July 2024. It is not a model trained on those 14 dates. A speech on a closed day is mapped to the next open session within three calendar days: 28 February 2015 uses 2 March, 1 February 2020 uses 3 February, and 1 February 2026 uses 2 February. 1 February 2025 is itself a row in the file.

On the mapped session the labels are 5 Entry, 7 Exit, and 2 Quiet. Volume is above its recent average on 12 of the 14 sessions. The average path, measured from the close five sessions before the speech session, is about +0.1% on the speech session and about +1.0% five sessions later.

What to say:

> Budget day is usually a busier NIFTY session. It is not a reliable rally on the day itself: seven of these sessions are labeled Exit, five Entry, two Quiet. Five sessions later the average close is about one percent above where it stood five sessions before the speech. That describes these 14 dates. It does not forecast the next budget.

---

## 6. Five viva questions and answers

Say the answers in your own words. The facts below are the ones to keep.

### 1. "Can this actually be used to make money?"

No. On Apple, both learned models have a worse price error than "tomorrow's close equals today's close." The paper account makes the same point in money: following the forest turned 10,000 into about 13,200, and buy-and-hold turned it into about 15,100, with no fees included. The direction score of 52% loses to a rule that always says up, because the test market rose on about 54% of days. A real trading rule would also have to survive brokerage costs, the gap between the price you see and the price you get, and the fact that the test window was one particular rising period. The project answers a classroom question: can a careful model, using only information known at today's close, beat a no-change guess on the next day's move? On these series, it cannot do so in a way I would bet on.

### 2. "Why didn't you use deep learning or an LSTM?"

An LSTM is a neural network designed for sequences. It can remember a long chain of past days. I did not use one for three practical reasons.

First, I have a few thousand daily rows and ten features. A deep network has a huge number of knobs and tends to memorize a table that small, unless you add a lot of machinery to stop it. Second, I cannot draw an LSTM weight on the board and tell you what it means. I can draw a tree question and a linear weight. Third, the no-change forecast is already extremely strong. A more complicated model would have to beat that forecast on a future period, not just fit the past more tightly. The literature on daily stock returns is full of models that fit history and fail the next year. I chose models I can explain, and I report that they do not beat the simple baseline.

If you want one polite extra line: "An LSTM would be a reasonable follow-up experiment. It would not change the evaluation rules: same time split, same naive baseline, same refusal to peek at tomorrow."

### 3. "What are the limitations?"

Keep four.

1. **The horizon is one day.** Almost all of tomorrow's price is already in today's price, so the thing left to predict is a small, noisy percent.
2. **The features are only the price's own history.** The model never sees earnings, interest rates, news, or a company announcement. A surprise headline can move the close in a way no moving average contains.
3. **One test window.** The Apple exam is mid-2024 through late 2026. A different decade could look different. NIFTY shows a tiny RMSE edge and Apple does not, which is already a warning against quoting one number as "the" result.
4. **Markets adapt.** If a pattern were obvious and large, traders would trade it until it shrank. A model that worked in the training years is not owed a repeat performance.

Also say what the project does well, so the answer is not an apology: the split is chronological, the features do not see the future, scaling is fit on the training rows only, and every learned model is compared with a no-change forecast.

### 4. "The actual-versus-predicted lines almost overlap. Why do you say the model is not accurate?"

Because both lines are mostly yesterday's price, redrawn. Suppose Apple closes at 220 today. Tomorrow it will probably close at 218 or 223, not at 150. Any forecast near 220 looks wonderful on a chart that runs from 25 dollars in 2015 to 350 dollars now. The fair test is the size of the miss compared with the miss you get by predicting zero change. On Apple that no-change RMSE is 4.29 dollars. Linear regression is 4.33. The forest is 4.37. The prettier line loses.

Same idea for R². An R² computed on the price level would look high. An R² computed on the daily return, which is the quantity we actually tried to learn, is about zero.

### 5. "Your direction accuracy is about 52%. Is that better than chance?"

Only if "chance" means a coin. It is not better than the obvious alternative. The Apple test market went up on 319 days and down on 275. Always saying UP scores 53.7%. The forest scores 52.2%, and the confusion grid shows it said UP on 491 of the 594 days. It learned that the recent era was a rising market, then repeated "up" most of the time. That is not a forecast of tomorrow's turn.

If they ask about NIFTY's 54.3%: the forest there does slightly beat the no-change price error, 201.06 versus 201.60 index points. I would call that a small and fragile edge on one series, and I would want a second time period before I described it as a pattern.

---

## A 90-second order of speech

1. Opening paragraph from section 1.
2. "One row is one day. I predict the percent change, then convert it back to a price."
3. "I do not shuffle. The last 20% of dates are the exam."
4. "Linear regression is a weighted sum. The random forest is 300 short trees, averaged, so one tree cannot memorize the past."
5. Point at the overlapping lines, then at the table. "The lines look close. The no-change row wins on Apple. Direction accuracy of 52% loses to always saying up."
6. Point at the equity chart. "Mood is just how many of the last 10 closes were up. Following the forest grew 10,000 to about 13,200. Holding grew it to about 15,100."
7. "I would not trade this. The value of the project is a clean test of a hard question."
8. If there is time, point at sections 8 and 9. "The 10-day bullish or bearish call does not beat always guessing the common label. Entry and exit are a volume proxy, not named investors. Around the Union Budget, NIFTY is usually busier, and the average path five sessions later is about one percent above the close from five sessions before. That is a description of those speeches, not a forecast."
