"""Download the bundled Yahoo Finance histories used by the app and notebook.

The CSVs are already saved in data/, so the presentation runs without internet.
Run this only when you want to refresh them:

    python download_data.py
"""

from __future__ import annotations

from pathlib import Path

import pandas as pd
import yfinance as yf

DATA_DIR = Path(__file__).resolve().parent / "data"
START = "2015-01-01"

# Yahoo symbols. NIFTY 50 is an index; the file is still saved as NIFTY50.csv
# so the rest of the project can refer to it by a simple name.
TICKERS = {
    "AAPL": "AAPL",
    "TSLA": "TSLA",
    "MSFT": "MSFT",
    "NIFTY50": "^NSEI",
}


def download_one(symbol: str) -> pd.DataFrame:
    """Download daily bars and return Date, Open, High, Low, Close, Volume."""
    downloaded = yf.download(
        symbol,
        start=START,
        auto_adjust=True,
        progress=False,
        threads=False,
    )
    if downloaded is None or downloaded.empty:
        raise RuntimeError(f"Yahoo Finance returned no rows for {symbol}.")

    frame = downloaded.copy()
    if isinstance(frame.columns, pd.MultiIndex):
        frame.columns = frame.columns.get_level_values(0)
    frame = frame.reset_index()
    keep = ["Date", "Open", "High", "Low", "Close", "Volume"]
    missing = [column for column in keep if column not in frame.columns]
    if missing:
        raise RuntimeError(f"{symbol} is missing columns: {', '.join(missing)}")
    return frame[keep].dropna(subset=["Date", "Close"])


def main() -> None:
    DATA_DIR.mkdir(parents=True, exist_ok=True)
    for name, symbol in TICKERS.items():
        prices = download_one(symbol)
        destination = DATA_DIR / f"{name}.csv"
        prices.to_csv(destination, index=False)
        print(f"{name:8} {symbol:8} {len(prices):5} rows -> {destination.name}")


if __name__ == "__main__":
    main()
