"""Print the full stock-prediction walkthrough in the terminal.

Usage:
    python train.py
    python train.py --dataset TSLA --test-size 0.2 --seed 42
"""

from __future__ import annotations

import argparse
from pathlib import Path

import pandas as pd

from src.pipeline import (
    BUNDLED_DATASETS,
    best_against_majority,
    budget_event_study,
    classification_table,
    explore_prices,
    load_budget_calendar,
    load_prices,
    results_table,
    run_pipeline,
    train_participation,
    train_regime,
)

DATA_DIR = Path(__file__).resolve().parent / "data"
BUDGET_CALENDAR = DATA_DIR / "union_budgets.csv"


def main() -> None:
    parser = argparse.ArgumentParser(description="Train the stock-prediction comparison.")
    parser.add_argument("--dataset", default="AAPL", choices=list(BUNDLED_DATASETS))
    parser.add_argument("--test-size", type=float, default=0.20)
    parser.add_argument("--seed", type=int, default=42)
    args = parser.parse_args()

    prices = load_prices(DATA_DIR / f"{args.dataset}.csv")
    summary = explore_prices(prices)
    print("Step 1. Data collection")
    print(f"  Dataset:  {BUNDLED_DATASETS[args.dataset]}")
    print(f"  Rows:     {summary['rows']}")
    print(f"  From:     {summary['start'].date()} to {summary['end'].date()}")
    print(f"  Missing:  {summary['missing_values']}")

    outcome = run_pipeline(prices, test_size=args.test_size, seed=args.seed)
    train = outcome["train"]
    test = outcome["test"]
    print("\nStep 2. Features and time-series split")
    print(f"  Rows after feature engineering: {len(outcome['featured'])}")
    print(
        f"  Train: {train['Date'].iloc[0].date()} to {train['Date'].iloc[-1].date()}"
        f" ({len(train)} days)"
    )
    print(
        f"  Test:  {test['Date'].iloc[0].date()} to {test['Date'].iloc[-1].date()}"
        f" ({len(test)} days)"
    )

    print("\nStep 3. Test-set scores")
    table = results_table(outcome["results"])
    print(table.to_string(index=False, float_format=lambda value: f"{value:,.4f}"))

    learned = [item for item in outcome["results"] if item.name != "Naive (no change)"]
    best = min(learned, key=lambda item: item.rmse_price)
    naive = next(item for item in outcome["results"] if item.name == "Naive (no change)")
    print(f"\nLowest price RMSE among learned models: {best.name}")
    if best.rmse_price < naive.rmse_price:
        print("It beats the no-change baseline on price RMSE.")
    else:
        print("It does not beat the no-change baseline on price RMSE.")
    print("A direction accuracy near 0.50 is a coin flip. Say that plainly in the viva.")

    regime = train_regime(prices, test_size=args.test_size, seed=args.seed)
    _print_classification(
        "Step 4. Bullish or bearish over the next 10 sessions",
        regime,
    )
    latest = regime["latest"]
    if latest["scored"]:
        print(
            f"  Latest close {latest['date'].date()}: {latest['label']} "
            f"({latest['probability']:.0%} forest probability). "
            f"Realized label: {latest['actual']}."
        )
    else:
        print(
            f"  Latest close {latest['date'].date()}: {latest['label']} "
            f"({latest['probability']:.0%} forest probability). "
            "The next 10 sessions are not finished, so this call is unscored."
        )

    participation = train_participation(prices, test_size=args.test_size, seed=args.seed)
    _print_classification(
        "Step 5. Next session: entry, exit, or quiet",
        participation,
    )

    print("\nStep 6. Union Budget case study on NIFTY 50")
    nifty_path = DATA_DIR / "NIFTY50.csv"
    if not nifty_path.exists() or not BUDGET_CALENDAR.exists():
        print("  Skipped. data/NIFTY50.csv or data/union_budgets.csv is missing.")
        return
    study = budget_event_study(
        load_prices(nifty_path),
        load_budget_calendar(BUDGET_CALENDAR),
    )
    events = study["events"]
    mapped = events.dropna(subset=["session"]).copy()
    print(f"  Speeches mapped to a session: {len(mapped)} of {len(events)}")
    show = pd.DataFrame(
        {
            "Announcement": mapped["announcement"].dt.strftime("%Y-%m-%d"),
            "Kind": mapped["kind"],
            "Session": mapped["session"].dt.strftime("%Y-%m-%d"),
            "Day return": mapped["day_return"],
            "Volume vs average": mapped["volume_ratio"] - 1.0,
            "Label": mapped["label"],
            "Next 5 sessions": mapped["next_5_return"],
        }
    )
    print(show.to_string(index=False, float_format=lambda value: f"{value:+.2%}"))
    print(
        f"  Average path uses {study['path_count']} speeches "
        "with five sessions on each side."
    )
    print("  Volume is an activity figure for comparing days, not a list of people.")


def _print_classification(title: str, outcome: dict) -> None:
    """Print one classifier comparison and whether it beat the majority class."""
    train = outcome["train"]
    test = outcome["test"]
    print(f"\n{title}")
    print(
        f"  Train: {train['Date'].iloc[0].date()} to {train['Date'].iloc[-1].date()}"
        f" ({len(train)} days)"
    )
    print(
        f"  Test:  {test['Date'].iloc[0].date()} to {test['Date'].iloc[-1].date()}"
        f" ({len(test)} days)"
    )
    table = classification_table(outcome["results"])
    print(table.to_string(index=False, float_format=lambda value: f"{value:,.4f}"))
    summary = best_against_majority(outcome["results"])
    best = summary["best_accuracy"]
    majority = summary["majority_accuracy"]
    if summary["beats_majority"]:
        print(
            f"  {summary['best_name']} beats the majority baseline "
            f"({best:.1%} vs {majority:.1%})."
        )
    else:
        print(
            f"  {summary['best_name']} does not beat the majority baseline "
            f"by more than one percentage point ({best:.1%} vs {majority:.1%})."
        )


if __name__ == "__main__":
    main()
