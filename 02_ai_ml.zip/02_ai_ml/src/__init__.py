"""Stock-prediction pipeline used by the notebook and the Streamlit app."""
