"""Next-day stock move pipeline, written as the same steps used in the viva.

The question we answer
-----------------------
At the end of trading day t, will the closing price on day t+1 be higher or
lower, and by about how much?

We predict the next-day *return* (the percentage change), then turn that
return back into a price:

    predicted close = today's close x (1 + predicted return)

Predicting the return, rather than the price itself, keeps the task honest.
Tomorrow's price is almost equal to today's price, so a model that simply
repeats today's close looks extremely accurate if you only glance at an
R-squared on the price. Comparing against that "no change" forecast shows
whether the model learned anything real.

Two further trainings use the same features and the same chronological split.
One classifies the next 10 sessions as Bullish or Bearish. The other
classifies the next session as Entry, Exit, or Quiet from the close and the
volume. A separate table reads the NIFTY path around Union Budget speeches.
That table is a case study, not a model fit on a dozen dates.

Leakage rules
-------------
* Every feature on row t is known when day t closes.
* The target on row t is the return from day t to day t+1.
* Rolling windows look backward only.
* The test set is the most recent block of rows. Nothing is shuffled.
"""

from __future__ import annotations

from dataclasses import dataclass

import numpy as np
import pandas as pd
from sklearn.ensemble import RandomForestClassifier, RandomForestRegressor
from sklearn.linear_model import LinearRegression, LogisticRegression
from sklearn.metrics import (
    accuracy_score,
    confusion_matrix,
    mean_absolute_error,
    mean_squared_error,
    r2_score,
)
from sklearn.pipeline import Pipeline
from sklearn.preprocessing import StandardScaler

# Columns a user-supplied CSV must contain. "Adj Close" is accepted in place
# of Close so a stock split does not look like a crash.
REQUIRED_COLUMNS = ["Date", "Open", "High", "Low", "Close", "Volume"]

# Bundled files live in data/<key>.csv. The label is what the app displays.
BUNDLED_DATASETS = {
    "AAPL": "Apple (AAPL)",
    "TSLA": "Tesla (TSLA)",
    "MSFT": "Microsoft (MSFT)",
    "NIFTY50": "NIFTY 50",
}

FEATURE_COLUMNS = [
    "return_1",
    "return_5",
    "return_10",
    "ma_5_ratio",
    "ma_10_ratio",
    "ma_20_ratio",
    "volatility_10",
    "oc_diff",
    "hl_range",
    "volume_change",
]

FEATURE_MEANINGS = {
    "return_1": "Today's percentage change in the close",
    "return_5": "Percentage change in the close over the last 5 days",
    "return_10": "Percentage change in the close over the last 10 days",
    "ma_5_ratio": "How far today's close sits from the 5-day moving average",
    "ma_10_ratio": "How far today's close sits from the 10-day moving average",
    "ma_20_ratio": "How far today's close sits from the 20-day moving average",
    "volatility_10": "How jumpy daily returns have been over the last 10 days",
    "oc_diff": "Open-to-close change, divided by the open",
    "hl_range": "High-to-low range, divided by the close",
    "volume_change": "Percentage change in volume versus yesterday",
}

TARGET_COLUMN = "target_return"

# Next 10 sessions: Bullish when that stretch finishes higher, Bearish otherwise.
REGIME_HORIZON = 10
REGIME_LABELS = ["Bearish", "Bullish"]

# Entry and exit are read from the close and from volume versus its own recent average.
PARTICIPATION_LABELS = ["Entry", "Exit", "Quiet"]
VOLUME_AVERAGE_WINDOW = 20

# A speech on a closed day uses the next open session, at most this many calendar days later.
BUDGET_MATCH_DAYS = 3
BUDGET_PATH_RADIUS = 5


def standardise_prices(frame: pd.DataFrame) -> pd.DataFrame:
    """Return a clean Date / Open / High / Low / Close / Volume table.

    Extra columns are ignored. Column names are matched without case
    sensitivity, and an adjusted close is preferred when both are present.
    """
    lookup = {str(column).strip().lower(): column for column in frame.columns}

    def pick(*names: str):
        for name in names:
            if name.lower() in lookup:
                return lookup[name.lower()]
        return None

    chosen = {
        "Date": pick("Date", "Datetime", "Timestamp"),
        "Open": pick("Open"),
        "High": pick("High"),
        "Low": pick("Low"),
        "Close": pick("Adj Close", "AdjClose", "Close"),
        "Volume": pick("Volume"),
    }
    missing = [name for name, column in chosen.items() if column is None]
    if missing:
        raise ValueError(
            "Missing required columns: "
            + ", ".join(missing)
            + ". Expected Date, Open, High, Low, Close, and Volume."
        )

    prices = pd.DataFrame(
        {
            "Date": pd.to_datetime(frame[chosen["Date"]], errors="coerce"),
            "Open": pd.to_numeric(frame[chosen["Open"]], errors="coerce"),
            "High": pd.to_numeric(frame[chosen["High"]], errors="coerce"),
            "Low": pd.to_numeric(frame[chosen["Low"]], errors="coerce"),
            "Close": pd.to_numeric(frame[chosen["Close"]], errors="coerce"),
            "Volume": pd.to_numeric(frame[chosen["Volume"]], errors="coerce"),
        }
    )
    prices = prices.dropna(subset=["Date", "Open", "High", "Low", "Close"])
    prices = prices.sort_values("Date").drop_duplicates("Date", keep="last")
    prices = prices.reset_index(drop=True)
    if len(prices) < 80:
        raise ValueError(
            "Need at least 80 trading days after cleaning. "
            f"This file has {len(prices)}."
        )
    return prices


def load_prices(source) -> pd.DataFrame:
    """Load prices from a CSV path or a file-like object."""
    return standardise_prices(pd.read_csv(source))


def explore_prices(prices: pd.DataFrame) -> dict:
    """Summarise the raw series for the exploration step."""
    daily_return = prices["Close"].pct_change()
    return {
        "rows": int(len(prices)),
        "start": prices["Date"].iloc[0],
        "end": prices["Date"].iloc[-1],
        "missing_values": int(prices.isna().sum().sum()),
        "last_close": float(prices["Close"].iloc[-1]),
        "mean_daily_return": float(daily_return.mean()),
        "std_daily_return": float(daily_return.std()),
    }


def _add_known_features(prices: pd.DataFrame) -> pd.DataFrame:
    """Add the ten features known at today's close. Early rows stay incomplete."""
    data = prices.copy()
    close = data["Close"]

    data["return_1"] = close.pct_change(1)
    data["return_5"] = close.pct_change(5)
    data["return_10"] = close.pct_change(10)

    data["ma_5"] = close.rolling(5).mean()
    data["ma_10"] = close.rolling(10).mean()
    data["ma_20"] = close.rolling(20).mean()
    data["ma_5_ratio"] = close / data["ma_5"] - 1
    data["ma_10_ratio"] = close / data["ma_10"] - 1
    data["ma_20_ratio"] = close / data["ma_20"] - 1

    data["volatility_10"] = data["return_1"].rolling(10).std()
    data["oc_diff"] = (data["Close"] - data["Open"]) / data["Open"]
    data["hl_range"] = (data["High"] - data["Low"]) / data["Close"]

    volume_change = data["Volume"].pct_change(1).replace([np.inf, -np.inf], np.nan)
    # An index such as NIFTY can have an empty volume column. A constant zero
    # keeps the feature list the same without throwing those rows away.
    if volume_change.notna().sum() < 30:
        volume_change = pd.Series(0.0, index=data.index)
    data["volume_change"] = volume_change
    return data.replace([np.inf, -np.inf], np.nan)


def engineer_features(prices: pd.DataFrame) -> pd.DataFrame:
    """Add features known today and the next-day return we want to predict.

    Rolling averages and percentage changes only see the current row and the
    rows above it. The target is shifted up by one day, so row t learns to
    predict day t+1. Rows that do not yet have a full 20-day window, and the
    final row that has no tomorrow, are dropped.
    """
    data = _add_known_features(prices)
    close = data["Close"]
    data["target_return"] = close.pct_change(1).shift(-1)
    data["next_close"] = close.shift(-1)

    data = data.replace([np.inf, -np.inf], np.nan).dropna().reset_index(drop=True)
    if len(data) < 60:
        raise ValueError(
            "Not enough rows remain after feature engineering. Use a longer price history."
        )
    return data


def time_series_split(featured: pd.DataFrame, test_size: float):
    """Keep the earliest rows for training and the latest rows for testing.

    A random split would let the model train on March and be tested on
    January. That is data leakage. This split never shuffles.
    """
    if not 0.05 <= float(test_size) <= 0.5:
        raise ValueError("Test set size must be between 0.05 and 0.5.")

    split_at = int(len(featured) * (1.0 - float(test_size)))
    split_at = min(max(split_at, 40), len(featured) - 20)
    train = featured.iloc[:split_at].copy()
    test = featured.iloc[split_at:].copy()
    if train["Date"].max() >= test["Date"].min():
        raise RuntimeError("Training dates overlap the test period.")
    return train, test


@dataclass
class ModelResult:
    """Scores and row-level forecasts for one model on the test period."""

    name: str
    rmse_price: float
    mae_price: float
    rmse_return: float
    mae_return: float
    r2_return: float
    direction_accuracy: float
    predictions: pd.DataFrame
    confusion: np.ndarray


@dataclass
class ClassResult:
    """Accuracy and confusion matrix for one classifier on the test period."""

    name: str
    accuracy: float
    confusion: np.ndarray


def _direction(returns: np.ndarray) -> np.ndarray:
    """1 when the close rises, 0 when it does not. A flat day counts as down."""
    return (np.asarray(returns) > 0).astype(int)


def _score(name, actual_return, actual_close, predicted_return, close_today, dates):
    predicted_return = np.asarray(predicted_return, dtype=float)
    predicted_close = np.asarray(close_today, dtype=float) * (1.0 + predicted_return)
    actual_direction = _direction(actual_return)
    predicted_direction = _direction(predicted_return)
    predictions = pd.DataFrame(
        {
            "Date": pd.to_datetime(dates),
            "actual_close": actual_close,
            "predicted_close": predicted_close,
            "actual_return": actual_return,
            "predicted_return": predicted_return,
            "actual_direction": np.where(actual_direction == 1, "UP", "DOWN"),
            "predicted_direction": np.where(predicted_direction == 1, "UP", "DOWN"),
        }
    )
    return ModelResult(
        name=name,
        rmse_price=float(np.sqrt(mean_squared_error(actual_close, predicted_close))),
        mae_price=float(mean_absolute_error(actual_close, predicted_close)),
        rmse_return=float(np.sqrt(mean_squared_error(actual_return, predicted_return))),
        mae_return=float(mean_absolute_error(actual_return, predicted_return)),
        r2_return=float(r2_score(actual_return, predicted_return)),
        direction_accuracy=float(accuracy_score(actual_direction, predicted_direction)),
        predictions=predictions,
        confusion=confusion_matrix(actual_direction, predicted_direction, labels=[0, 1]),
    )


def train_and_evaluate(train: pd.DataFrame, test: pd.DataFrame, seed: int) -> dict:
    """Fit linear regression and a random forest, and score a no-change baseline.

    The linear model is scaled inside a pipeline, and the scaler is fit on the
    training rows only. The forest does not need scaling. The baseline predicts
    a return of zero, which means "tomorrow's close equals today's close".
    """
    x_train = train[FEATURE_COLUMNS]
    y_train = train[TARGET_COLUMN]
    x_test = test[FEATURE_COLUMNS]

    linear = Pipeline(
        steps=[
            ("scaler", StandardScaler()),
            ("model", LinearRegression()),
        ]
    )
    forest = RandomForestRegressor(
        n_estimators=300,
        max_depth=6,
        min_samples_leaf=5,
        random_state=int(seed),
        n_jobs=-1,
    )
    linear.fit(x_train, y_train)
    forest.fit(x_train, y_train)

    actual_return = test[TARGET_COLUMN].to_numpy()
    actual_close = test["next_close"].to_numpy()
    close_today = test["Close"].to_numpy()
    dates = test["Date"].to_numpy()

    results = [
        _score(
            "Naive (no change)",
            actual_return,
            actual_close,
            np.zeros(len(test)),
            close_today,
            dates,
        ),
        _score(
            "Linear Regression",
            actual_return,
            actual_close,
            linear.predict(x_test),
            close_today,
            dates,
        ),
        _score(
            "Random Forest",
            actual_return,
            actual_close,
            forest.predict(x_test),
            close_today,
            dates,
        ),
    ]

    coefficients = pd.DataFrame(
        {
            "feature": FEATURE_COLUMNS,
            "meaning": [FEATURE_MEANINGS[name] for name in FEATURE_COLUMNS],
            "coefficient": linear.named_steps["model"].coef_,
        }
    )
    coefficients["abs_coefficient"] = coefficients["coefficient"].abs()
    coefficients = coefficients.sort_values("abs_coefficient", ascending=False).drop(
        columns="abs_coefficient"
    )

    importances = pd.DataFrame(
        {
            "feature": FEATURE_COLUMNS,
            "meaning": [FEATURE_MEANINGS[name] for name in FEATURE_COLUMNS],
            "importance": forest.feature_importances_,
        }
    ).sort_values("importance", ascending=False)

    return {
        "results": results,
        "coefficients": coefficients.reset_index(drop=True),
        "importances": importances.reset_index(drop=True),
    }


def run_pipeline(prices: pd.DataFrame, test_size: float, seed: int) -> dict:
    """Run feature engineering, the time split, and model comparison."""
    featured = engineer_features(prices)
    train, test = time_series_split(featured, test_size)
    trained = train_and_evaluate(train, test, seed)
    return {
        "prices": prices,
        "featured": featured,
        "train": train,
        "test": test,
        **trained,
    }


MOOD_WINDOW = 10
STARTING_CAPITAL = 10_000.0


def mood_label(up_rate: float) -> str:
    """Turn a 10-day up-rate into a word a presenter can say."""
    if up_rate >= 0.60:
        return "Bullish"
    if up_rate >= 0.40:
        return "Mixed"
    return "Bearish"


def market_mood(prices: pd.DataFrame, window: int = MOOD_WINDOW) -> dict:
    """Share of the last `window` sessions that closed higher than the day before.

    The rate on a day uses that day's close and the previous closes only.
    It is a price mood, not a reading of news or social media.
    """
    frame = prices[["Date", "Close"]].copy()
    closed_higher = frame["Close"].pct_change() > 0
    up_rate = closed_higher.rolling(window, min_periods=window).mean()
    history = pd.DataFrame({"Date": frame["Date"], "mood": up_rate}).dropna()
    history = history.reset_index(drop=True)
    latest = float(history["mood"].iloc[-1])
    return {
        "latest": latest,
        "label": mood_label(latest),
        "window": int(window),
        "history": history,
    }


def paper_trading(
    predictions: pd.DataFrame, starting_capital: float = STARTING_CAPITAL
) -> dict:
    """What-if account for the test period. No fees and no slippage.

    The account holds for the next session when the model predicts a positive
    return, and sits in cash otherwise. Buy-and-hold stays invested every day.
    This is a replay of days that already happened, not a promise of future profit.
    """
    held = predictions["predicted_return"].to_numpy() > 0
    actual_return = predictions["actual_return"].to_numpy()
    strategy_return = np.where(held, actual_return, 0.0)
    strategy_equity = float(starting_capital) * np.cumprod(1.0 + strategy_return)
    buy_hold_equity = float(starting_capital) * np.cumprod(1.0 + actual_return)
    curve = pd.DataFrame(
        {
            "Date": predictions["Date"].to_numpy(),
            "strategy_equity": strategy_equity,
            "buy_hold_equity": buy_hold_equity,
            "held": held,
        }
    )
    ending_strategy = float(strategy_equity[-1])
    ending_buy_hold = float(buy_hold_equity[-1])
    return {
        "curve": curve,
        "starting_capital": float(starting_capital),
        "ending_strategy": ending_strategy,
        "ending_buy_hold": ending_buy_hold,
        "profit_strategy": ending_strategy - float(starting_capital),
        "profit_buy_hold": ending_buy_hold - float(starting_capital),
        "days_invested": int(held.sum()),
        "test_days": int(len(predictions)),
    }


def _class_score(name: str, actual, predicted, labels: list[str]) -> ClassResult:
    """Score predicted labels against the realized labels, in a fixed order."""
    return ClassResult(
        name=name,
        accuracy=float(accuracy_score(actual, predicted)),
        confusion=confusion_matrix(actual, predicted, labels=list(labels)),
    )


def _fit_classifiers(
    train: pd.DataFrame,
    test: pd.DataFrame,
    target_column: str,
    labels: list[str],
    seed: int,
) -> dict:
    """Fit a majority baseline, logistic regression, and a random forest.

    The logistic model is scaled inside a pipeline fit on the training rows
    only. The forest uses the same depth cap as the price model. The baseline
    always guesses the most common training label.
    """
    x_train = train[FEATURE_COLUMNS]
    y_train = train[target_column].astype(str)
    x_test = test[FEATURE_COLUMNS]
    y_test = test[target_column].astype(str).to_numpy()
    majority = str(y_train.value_counts().idxmax())

    logistic = Pipeline(
        steps=[
            ("scaler", StandardScaler()),
            ("model", LogisticRegression(max_iter=1000, random_state=int(seed))),
        ]
    )
    forest = RandomForestClassifier(
        n_estimators=300,
        max_depth=6,
        min_samples_leaf=5,
        random_state=int(seed),
        n_jobs=-1,
    )
    logistic.fit(x_train, y_train)
    forest.fit(x_train, y_train)
    results = [
        _class_score("Majority class", y_test, np.full(len(y_test), majority), labels),
        _class_score("Logistic Regression", y_test, logistic.predict(x_test), labels),
        _class_score("Random Forest", y_test, forest.predict(x_test), labels),
    ]
    return {"results": results, "forest": forest}


def _predict_label(forest, row: pd.DataFrame) -> tuple[str, float]:
    """Return the forest's label for one row and the probability of that label."""
    features = row[FEATURE_COLUMNS]
    label = str(forest.predict(features)[0])
    probabilities = forest.predict_proba(features)[0]
    classes = [str(name) for name in forest.classes_]
    return label, float(probabilities[classes.index(label)])


def classification_table(results: list[ClassResult]) -> pd.DataFrame:
    """One row per classifier, in the order they should be presented."""
    return pd.DataFrame(
        [{"Model": item.name, "Accuracy": item.accuracy} for item in results]
    )


def best_against_majority(results: list[ClassResult]) -> dict:
    """Compare the stronger learned classifier with the majority baseline.

    A lead of one percentage point or less is reported as not beating the
    baseline. A smaller gap is too close to call a result in a presentation.
    """
    majority = next(item for item in results if item.name == "Majority class")
    learned = [item for item in results if item.name != "Majority class"]
    best = max(learned, key=lambda item: item.accuracy)
    return {
        "best_name": best.name,
        "best_accuracy": best.accuracy,
        "majority_accuracy": majority.accuracy,
        "beats_majority": best.accuracy > majority.accuracy + 0.01,
    }


def _require_scored_rows(scored: pd.DataFrame, task: str) -> None:
    if len(scored) < 60:
        raise ValueError(
            f"Not enough rows remain to score {task}. Use a longer price history."
        )


def build_regime_frame(
    prices: pd.DataFrame, horizon: int = REGIME_HORIZON
) -> pd.DataFrame:
    """Features known today, plus the realized label for the next `horizon` sessions.

    Bullish means the close `horizon` sessions ahead is higher than today's
    close. Bearish means it is not. The last `horizon` rows keep their features
    and have no label, so a caller can still ask for a current call.
    """
    data = _add_known_features(prices)
    close = data["Close"]
    forward = (close.shift(-horizon) / close - 1.0).replace([np.inf, -np.inf], np.nan)
    data["forward_return"] = forward
    data["regime"] = pd.Series(pd.NA, index=data.index, dtype="object")
    known = forward.notna()
    data.loc[known & (forward > 0), "regime"] = "Bullish"
    data.loc[known & (forward <= 0), "regime"] = "Bearish"
    return data.dropna(subset=FEATURE_COLUMNS).reset_index(drop=True)


def train_regime(
    prices: pd.DataFrame,
    test_size: float,
    seed: int,
    horizon: int = REGIME_HORIZON,
) -> dict:
    """Classify the next `horizon` sessions as Bullish or Bearish.

    The latest close is scored with the forest trained on the training block
    only. When the following sessions have not finished, that call is marked
    unscored and is left out of the accuracy.
    """
    frame = build_regime_frame(prices, horizon=horizon)
    scored = frame.dropna(subset=["regime"]).reset_index(drop=True)
    _require_scored_rows(scored, "the bullish or bearish call")
    train, test = time_series_split(scored, test_size)
    fitted = _fit_classifiers(train, test, "regime", REGIME_LABELS, seed)

    latest_row = frame.iloc[[-1]]
    label, probability = _predict_label(fitted["forest"], latest_row)
    actual = latest_row["regime"].iloc[0]
    has_outcome = bool(pd.notna(actual))
    return {
        "horizon": int(horizon),
        "labels": list(REGIME_LABELS),
        "train": train,
        "test": test,
        "results": fitted["results"],
        "latest": {
            "date": pd.Timestamp(latest_row["Date"].iloc[0]),
            "label": label,
            "probability": probability,
            "scored": has_outcome,
            "actual": str(actual) if has_outcome else None,
        },
    }


def _volume_ratio(volume: pd.Series, window: int = VOLUME_AVERAGE_WINDOW) -> pd.Series:
    """Today's volume divided by its trailing average. Zero averages become missing."""
    average = volume.rolling(window).mean().replace(0, np.nan)
    ratio = volume / average
    return ratio.replace([np.inf, -np.inf], np.nan)


def day_participation(day_return: pd.Series, volume_ratio: pd.Series) -> pd.Series:
    """Label a finished session from its own close and its own volume.

    Entry: the close rose and volume was at least its recent average.
    Exit: the close fell and volume was at least that average.
    Quiet: volume was below that average, or the close did not move.
    A missing return or a missing volume ratio stays missing.
    """
    labels = pd.Series(pd.NA, index=day_return.index, dtype="object")
    known = day_return.notna() & volume_ratio.notna()
    quiet = known & ((volume_ratio < 1.0) | (day_return == 0))
    entry = known & (volume_ratio >= 1.0) & (day_return > 0)
    leaving = known & (volume_ratio >= 1.0) & (day_return < 0)
    labels.loc[quiet] = "Quiet"
    labels.loc[entry] = "Entry"
    labels.loc[leaving] = "Exit"
    return labels


def build_participation_frame(prices: pd.DataFrame) -> pd.DataFrame:
    """Features known today, and tomorrow's entry / exit / quiet label.

    The label on a row is the next session, so today's close and today's
    volume are not the answer. They are only allowed in as today's features.
    """
    data = _add_known_features(prices)
    data["volume_ratio"] = _volume_ratio(data["Volume"])
    data["participation"] = day_participation(data["return_1"], data["volume_ratio"])
    data["target_participation"] = data["participation"].shift(-1)
    return data.dropna(subset=FEATURE_COLUMNS).reset_index(drop=True)


def train_participation(prices: pd.DataFrame, test_size: float, seed: int) -> dict:
    """Predict whether the next session is Entry, Exit, or Quiet."""
    frame = build_participation_frame(prices)
    scored = frame.dropna(subset=["target_participation"]).reset_index(drop=True)
    _require_scored_rows(scored, "entry and exit")
    train, test = time_series_split(scored, test_size)
    fitted = _fit_classifiers(train, test, "target_participation", PARTICIPATION_LABELS, seed)
    return {
        "labels": list(PARTICIPATION_LABELS),
        "train": train,
        "test": test,
        "results": fitted["results"],
    }


def load_budget_calendar(source) -> pd.DataFrame:
    """Read a speech calendar with a date column and a kind column."""
    frame = pd.read_csv(source)
    lookup = {str(column).strip().lower(): column for column in frame.columns}
    if "date" not in lookup or "kind" not in lookup:
        raise ValueError("Budget calendar needs date and kind columns.")
    events = pd.DataFrame(
        {
            "date": pd.to_datetime(frame[lookup["date"]], errors="coerce"),
            "kind": frame[lookup["kind"]].astype(str).str.strip(),
        }
    )
    events = events.dropna(subset=["date"]).sort_values("date")
    events = events.drop_duplicates("date", keep="last").reset_index(drop=True)
    if events.empty:
        raise ValueError("Budget calendar has no dated rows.")
    return events


def budget_event_study(
    prices: pd.DataFrame,
    events: pd.DataFrame,
    radius: int = BUDGET_PATH_RADIUS,
) -> dict:
    """Describe NIFTY sessions around Union Budget speeches.

    Each speech is mapped to the first trading day on that date or within the
    next three calendar days. The path is the average percent change from the
    close five sessions before the mapped session. This does not fit a model.
    """
    frame = prices.sort_values("Date").drop_duplicates("Date", keep="last").reset_index(drop=True)
    close = frame["Close"]
    day_return = close.pct_change()
    volume_ratio = _volume_ratio(frame["Volume"])
    labels = day_participation(day_return, volume_ratio)
    dates = pd.to_datetime(frame["Date"]).dt.normalize()

    rows = []
    for event in events.itertuples(index=False):
        announced = pd.Timestamp(event.date).normalize()
        window_end = announced + pd.Timedelta(days=BUDGET_MATCH_DAYS)
        matches = frame.index[(dates >= announced) & (dates <= window_end)]
        row = {
            "announcement": announced,
            "kind": str(event.kind),
            "session": pd.NaT,
            "day_return": np.nan,
            "volume_ratio": np.nan,
            "label": None,
            "next_5_return": np.nan,
        }
        if len(matches) == 0:
            rows.append(row)
            continue
        index = int(matches[0])
        row["session"] = pd.Timestamp(dates.iloc[index])
        if pd.notna(day_return.iloc[index]):
            row["day_return"] = float(day_return.iloc[index])
        if pd.notna(volume_ratio.iloc[index]):
            row["volume_ratio"] = float(volume_ratio.iloc[index])
        label = labels.iloc[index]
        row["label"] = None if pd.isna(label) else str(label)
        future_index = index + 5
        if (
            future_index < len(frame)
            and pd.notna(close.iloc[index])
            and close.iloc[index] != 0
            and pd.notna(close.iloc[future_index])
        ):
            row["next_5_return"] = float(close.iloc[future_index] / close.iloc[index] - 1.0)
        rows.append(row)

    table = pd.DataFrame(rows)
    offsets = list(range(-radius, radius + 1))
    paths = []
    for session in table["session"].dropna():
        matches = frame.index[dates == pd.Timestamp(session).normalize()]
        if len(matches) == 0:
            continue
        index = int(matches[0])
        if index - radius < 0 or index + radius >= len(frame):
            continue
        base_close = float(close.iloc[index - radius])
        if pd.isna(base_close) or base_close == 0:
            continue
        window = [float(close.iloc[index + offset] / base_close - 1.0) for offset in offsets]
        if np.isnan(window).any():
            continue
        paths.append(window)

    if paths:
        mean_return = np.mean(np.asarray(paths, dtype=float), axis=0)
    else:
        mean_return = np.full(len(offsets), np.nan)
    return {
        "events": table,
        "path": pd.DataFrame({"offset": offsets, "mean_return": mean_return}),
        "path_count": int(len(paths)),
    }


def results_table(results: list[ModelResult]) -> pd.DataFrame:
    """One row per model, in the order they should be presented."""
    return pd.DataFrame(
        [
            {
                "Model": item.name,
                "RMSE (price)": item.rmse_price,
                "MAE (price)": item.mae_price,
                "RMSE (return)": item.rmse_return,
                "MAE (return)": item.mae_return,
                "R² (return)": item.r2_return,
                "Direction accuracy": item.direction_accuracy,
            }
            for item in results
        ]
    )
