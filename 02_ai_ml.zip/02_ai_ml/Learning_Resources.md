# Learning resources for this project

A reading and watching list for building a project like this one: daily prices from Yahoo Finance, features known only at today's close, a time-ordered test set, a no-change baseline, linear regression, a random forest, and a Streamlit page that shows the scores.

Each link is paired with what it covers and where it shows up in this repo (`src/pipeline.py`, `app.py`, `notebooks/stock_price_prediction.ipynb`).

Many popular "stock price prediction" videos report a very high accuracy because they predict the price level. Tomorrow's close is almost today's close, so a chart of predicted versus actual prices looks tight even when the model has learned nothing about the next move. This project predicts the percent change and always shows the no-change forecast beside the learned models. Read the last section before copying a tutorial that claims 95% accuracy.

---

## 1. The shape of the project

What to learn: supervised regression on a table of past days, then a held-out period the model has never seen.

**Videos**

- [A Gentle Introduction to Machine Learning (StatQuest)](https://www.youtube.com/watch?v=Gv9_4yMHFhI) — Training rows have inputs and a known answer. A separate set of rows is used only to score the model. That is the split between the earlier dates and the last 20% of dates in this project.
- [Scikit-learn Crash Course (freeCodeCamp, Vincent Warmerdam)](https://www.youtube.com/watch?v=0B5eIE_1vpU) — How a scikit-learn estimator is fit, how preprocessing belongs in a pipeline, and how a metric judges the result. About two hours. The companion write-up is [Python scikit-learn Tutorial](https://www.freecodecamp.org/news/learn-scikit-learn/).

**Articles**

- [Getting started with scikit-learn](https://scikit-learn.org/stable/getting_started.html) — The `fit` / `predict` pattern used for both `LinearRegression` and `RandomForestRegressor`.
- [Common pitfalls and recommended practices](https://scikit-learn.org/stable/common_pitfalls.html) — The page that matches this project's rules: fit the scaler on the training rows only, and put scaling inside a `Pipeline` so the test rows are transformed with the training mean and standard deviation.

---

## 2. Tables in pandas

What to learn: load a CSV, sort by date, drop bad rows, and add columns. That is `load_prices` and the feature step.

**Videos**

- [Pandas Tutorials (Corey Schafer, playlist)](https://www.youtube.com/playlist?list=PL-osiE80TeTsWmV9i9c58mdDCSskIFdDS) — Short videos on DataFrames, selecting columns, and cleaning. Start here if pandas is new.
- [Pandas & Python for Data Analysis by Example (freeCodeCamp)](https://www.youtube.com/watch?v=gtjxAH8uaP0) — Longer, project-style practice: selection, new columns, and summaries.

**Articles**

- [10 minutes to pandas](https://pandas.pydata.org/docs/user_guide/10min.html) — The official tour: read a table, select, filter, and compute a new column.
- [`Series.rolling`](https://pandas.pydata.org/docs/reference/api/pandas.Series.rolling.html) — The moving window behind `ma_5_ratio`, `ma_10_ratio`, `ma_20_ratio`, and `volatility_10`. Keep `center=False` (the default) so the window ends on today and does not average in tomorrow.

---

## 3. Downloading the prices

What to learn: pull daily Open, High, Low, Close, and Volume, prefer the adjusted close so a stock split is not treated as a crash, and save a CSV so the demo can run offline. That is `download_data.py` and the files in `data/`.

**Videos**

- [yfinance Crash Course: Financial Programming in Python](https://www.youtube.com/watch?v=OQBvSQhkehs) — `Ticker.history` and `yf.download` for Apple and Microsoft, and what the Open / High / Low / Close / Volume columns mean.

**Articles**

- [How to download market data with yfinance and Python](https://pythonfintech.com/articles/how-to-download-market-data-yfinance-python/) — `start`, `end`, `interval="1d"`, and `auto_adjust=True`, which rewrites prices so splits and dividends do not create fake jumps.
- [Downloading historical prices with yfinance (Quant500)](https://quant500.com/en/academia/module/nivel-3/m3a) — Why the adjusted close is the series to use for returns, and why saving the download to CSV is the right habit. This project already does that.
- [yfinance `download` reference](https://ranaroussi.github.io/yfinance/reference/yfinance.functions.html) — The parameter list, including the limit that intraday bars only cover a short recent window. This project uses daily bars, which are the right grain for a next-day close.

---

## 4. Features that do not peek at tomorrow

What to learn: returns, distance from a moving average, volatility, the day's open-to-close move, the high-low range, and the change in volume. Every one of those is known when today's market closes.

**Videos**

- [Fix Rolling Feature Leakage in Python](https://www.youtube.com/watch?v=tLQ63XluET4) — A rolling mean with `center=True`, or a window that includes the next row, stores tomorrow's number in today's feature. The video shows the bad window and the shift that keeps the feature historical.

**Articles**

- [Lookahead bias in pandas: 8 ways a backtest sees the future](https://nothingbutalpha.app/learn/lookahead-bias-pandas) — Concrete pandas mistakes: a centered rolling window, a label that reaches into the test period, and `train_test_split` with shuffling left on. It also shows `TimeSeriesSplit(..., gap=...)` when the label looks several bars ahead. This project predicts one day ahead and cuts the split on time, which is the same idea in a simpler form.
- [Train-test split in pandas and scikit-learn (avoid data leakage)](https://www.mathewkanalytics.com/lessons/pandas-full-course/053-splitting-data-into-train-test-sets/) — A worked example where a shuffled split puts earlier dates into the test set. The fix is a date cutoff: train on the past, test on the later dates. Same rule as the test-size slider in `app.py`.

---

## 5. The no-change baseline

What to learn: the forecast "tomorrow's close equals today's close." A learned model is only useful if it beats this on the test days. On the default Apple run, linear regression and the forest do not beat it on price RMSE.

**Articles**

- [Some simple forecasting methods (Forecasting: Principles and Practice)](https://otexts.com/fpp3/toolbox.html) — Rob Hyndman and George Athanasopoulos. The naïve method sets every forecast equal to the last observation. For prices that behave like a random walk, that forecast is the benchmark, and a fancier model has to beat it before it is worth using. Section 5.2 is the part to read. The code samples are in R. The idea is the no-change line in this project.
- [Machine learning in finance: why you should not use LSTMs to predict the stock market (Bluesky Capital)](https://www.blueskycapitalmanagement.com/machine-learning-in-finance-why-you-should-not-use-lstms-to-predict-the-stock-market/) — An LSTM on the S&P 500 looks excellent on a price chart and on RMSE. Zoom in and the forecast is almost a one-day lag of the real price. That is the chart illusion this project is built to avoid.
- [Predicting the stock market is hard (Towards Data Science)](https://towardsdatascience.com/predicting-the-stock-market-is-hard-creating-a-machine-learning-model-probably-wont-help-e449039c9fe3/) — Today's price already carries almost all of tomorrow's price. Lagged prices fit today's price extremely well, which is what a random walk looks like, and it is why a model of the price level flatters itself.

---

## 6. Linear regression

What to learn: one weight per feature, chosen to minimise squared error. A positive weight means a larger feature pushes the predicted return up. This is the simple learned baseline in the app.

**Videos**

- [Linear Regression, Clearly Explained (StatQuest)](https://www.youtube.com/watch?v=7ArmBVF2dCs) — Least squares, then R-squared. The picture of "a straight line through the training points" is the right one for the weights in `pipeline.py`.
- [R-squared, Clearly Explained (StatQuest)](https://www.youtube.com/watch?v=2AQKmw14mHM) — What the return R² in the score table is measuring: how much of the variation in the target the line explains. On next-day returns that number stays near zero, which is the honest result.

**Articles**

- [Linear models (scikit-learn user guide)](https://scikit-learn.org/stable/modules/linear_model.html) — Ordinary least squares, the objective the training step minimises, and `coef_` / `intercept_`.
- [Ordinary least squares example](https://scikit-learn.org/stable/auto_examples/linear_model/plot_ols_ridge.html) — Fit on a train slice, score with mean squared error and R², and plot the line. The example uses `train_test_split(..., shuffle=False)`, which keeps time order.
- [Preprocessing and StandardScaler](https://scikit-learn.org/stable/modules/preprocessing.html) — Why the linear model in this project scales features inside the pipeline. A feature in the thousands (raw volume) would otherwise dominate a feature that lives near zero (a one-day return).

---

## 7. Decision trees and the random forest

What to learn: one tree asks a chain of yes/no questions and ends at a predicted return. A single tree memorizes the training days. The forest grows many short trees on random rows and random features, then averages them. This project uses 300 trees and caps depth at 6.

**Videos**

- [Decision Trees (StatQuest)](https://www.youtube.com/watch?v=7VeUPuFGJHk) — Watch this before the forest video. Root, splits, and leaves, and how a feature is chosen for a split.
- [Random Forests Part 1: Building, Using and Evaluating (StatQuest)](https://www.youtube.com/watch?v=J4Wdy0Wc_xQ) — Bootstrap samples, a random subset of features at each split, and averaging the trees. That is `RandomForestRegressor` in this project. The video's example is classification. The same construction is used here for a numeric return.

**Articles**

- [`RandomForestRegressor`](https://scikit-learn.org/stable/modules/generated/sklearn.ensemble.RandomForestRegressor.html) — `n_estimators`, `max_depth`, `max_features`, and `random_state`. The seed only changes which rows and features each tree sees. It does not shuffle time.
- [Feature importances example](https://scikit-learn.org/stable/auto_examples/ensemble/plot_forest_importances.html) — How the bar chart in the app is computed. On the default Apple run, 10-day volatility is the feature the forest uses most.

---

## 8. Scores: RMSE, MAE, R², and direction

What to learn: price RMSE and MAE say how far the predicted close was from the real close, in currency units. Return RMSE and R² score the percent change. Direction accuracy is the share of test days where up versus down was right. About 50% is a coin flip.

**Articles**

- [Regression metrics (scikit-learn)](https://scikit-learn.org/stable/modules/model_evaluation.html#regression-metrics) — Definitions of mean squared error, root mean squared error, mean absolute error, and R². RMSE penalises large misses more than MAE.
- [Accuracy and the confusion matrix](https://scikit-learn.org/stable/modules/generated/sklearn.metrics.confusion_matrix.html) — The up/down table in the app. Direction is not what the model is trained on. It is derived by asking whether the predicted return is positive.
- [TimeSeriesSplit](https://scikit-learn.org/stable/modules/generated/sklearn.model_selection.TimeSeriesSplit.html) — The scikit-learn splitter that refuses to train on the future. This project uses one cut (the last 20%) rather than several folds. The same warning applies: do not shuffle.
- [Building a stock-direction classifier with a time split](https://lowhangingdata.com/article/building-a-stock-prediction-svm/) — A different model (an SVM on intraday bars), same discipline: cutoff dates, scaler fit on train only, and a test window that is touched at the end. Useful as a second example of the pipeline, not as a claim that direction is easy.

---

## 9. The Streamlit page and the charts

What to learn: widgets for the ticker and the test size, a table of scores, and Plotly charts of actual versus predicted closes. That is `app.py`. The notebook draws the same pictures with Matplotlib and Seaborn.

**Videos**

- [Build 12 Data Science Apps with Python and Streamlit (freeCodeCamp)](https://www.youtube.com/watch?v=JwSS70SZdyM) — About three hours. Apps 1 and 5 are stock-price pages (a simple ticker chart and an S&P 500 explorer), and later apps embed a regression model in the page. The write-up, with the list of apps, is [on freeCodeCamp News](https://www.freecodecamp.org/news/build-12-data-science-apps-with-python-and-streamlit/).
- [Streamlit Crash Course: From Zero to Data App (Data Professor)](https://www.youtube.com/watch?v=d7fnzDQ5qM8) — A shorter path from an empty script to `streamlit run`, which is how this demo is started.

**Articles**

- [Basic concepts of Streamlit](https://docs.streamlit.io/get-started/fundamentals/main-concepts) — `streamlit run` and `python -m streamlit run`, plus text, tables, and charts. This matches `Steps to run.md`.
- [`st.plotly_chart`](https://docs.streamlit.io/develop/api-reference/charts/st.plotly_chart) — How a Plotly figure is placed on the page. The app passes the actual-versus-predicted figure here.
- [Line charts in Python (Plotly)](https://plotly.com/python/line-charts/) — Two lines on one date axis: actual close and predicted close.
- [Candlestick charts in Python (Plotly)](https://plotly.com/python/candlestick-charts/) — Open, high, low, and close for one symbol, including a ready-made Apple example. The demo's main chart is a line chart. This page is the next chart to add if you want the raw daily bar.

---

## 10. Why the result is close to a coin flip

What to learn: in a liquid market, past prices are a weak guide to tomorrow's direction. Saying that clearly is part of the project, not a failure of it.

**Articles**

- [The Efficient Market Hypothesis and Its Critics (Burton Malkiel, Journal of Economic Perspectives, 2003)](https://web.mit.edu/lewellen/www/Documents/Malkiel%20JEP%202003%20.pdf) — If news is reflected in the price quickly, tomorrow's change is tomorrow's news, and news is not in today's return, moving average, or volume. The PDF is a readable survey, including the criticisms. The weak form (past prices do not forecast future prices) is the claim this project is illustrating.
- [Validating weak-form market efficiency with machine learning (arXiv:1909.05151)](https://arxiv.org/abs/1909.05151) — Several models trained on price-based features, then checked after costs. The finding is little reliable predictive power, which lines up with direction accuracy near 50–52% in this app.

---

## A short path through the list

If you only have time for six of these, use this order:

1. [Gentle introduction to machine learning](https://www.youtube.com/watch?v=Gv9_4yMHFhI) — what training and testing are.
2. [10 minutes to pandas](https://pandas.pydata.org/docs/user_guide/10min.html) — the table the model is built on.
3. [yfinance crash course](https://www.youtube.com/watch?v=OQBvSQhkehs) — where `data/AAPL.csv` and the other files come from.
4. [Linear regression, clearly explained](https://www.youtube.com/watch?v=7ArmBVF2dCs) and [Random forests part 1](https://www.youtube.com/watch?v=J4Wdy0Wc_xQ) — the two learned models.
5. [Naïve forecasts](https://otexts.com/fpp3/toolbox.html) and the [Bluesky Capital LSTM write-up](https://www.blueskycapitalmanagement.com/machine-learning-in-finance-why-you-should-not-use-lstms-to-predict-the-stock-market/) — why the no-change line is on every chart.
6. [Streamlit in 12 apps](https://www.youtube.com/watch?v=JwSS70SZdyM) — how `app.py` becomes the page you present.
