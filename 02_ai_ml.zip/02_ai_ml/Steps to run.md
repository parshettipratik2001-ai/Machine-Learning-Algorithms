# Steps to run

Step 1. Extract the downloaded ZIP file.

Step 2. Open a terminal in the extracted project folder.

- Windows: open the folder, click the address bar, type `cmd`, and press Enter.
- macOS or Linux: open a terminal and `cd` into the project folder.

Step 3. Create and activate a virtual environment.

Run this in the terminal:

```bash
python -m venv venv
```

Windows:

```bash
venv\Scripts\activate
```

macOS or Linux:

```bash
source venv/bin/activate
```

Step 4. Install the dependencies.

```bash
python -m pip install --upgrade pip
pip install -r requirements.txt
```

Step 5. Launch the Streamlit app.

```bash
python -m streamlit run app.py
```

The app opens at <http://localhost:8501>. The price files are already in `data/`, so this step does not need internet.

If the command `streamlit` is not recognised, you are outside the virtual environment. Activate it again and use `python -m streamlit run app.py`.

Step 6. Optional: open the notebook used for the viva.

```bash
pip install jupyter
jupyter notebook notebooks/stock_price_prediction.ipynb
```

Step 7. Optional: refresh the Yahoo Finance files.

```bash
python download_data.py
```

Step 8. Optional: print the scores in the terminal.

```bash
python train.py
python train.py --dataset NIFTY50 --test-size 0.2 --seed 42
```
